<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../AboutDialog.ui" line="14"/>
        <source>About DB Browser for SQLite</source>
        <translation>О программе Обозреватель для SQLite</translation>
    </message>
    <message>
        <location filename="../AboutDialog.ui" line="47"/>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <location filename="../AboutDialog.ui" line="102"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;DB Browser for SQLite is an open source, freeware visual tool used to create, design and edit SQLite database files.&lt;/p&gt;&lt;p&gt;It is bi-licensed under the Mozilla Public License Version 2, as well as the GNU General Public License Version 3 or later. You can modify or redistribute it under the conditions of these licenses.&lt;/p&gt;&lt;p&gt;See &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;http://www.gnu.org/licenses/gpl.html&lt;/a&gt; and &lt;a href=&quot;https://www.mozilla.org/MPL/2.0/index.txt&quot;&gt;https://www.mozilla.org/MPL/2.0/index.txt&lt;/a&gt; for details.&lt;/p&gt;&lt;p&gt;For more information on this program please visit our website at: &lt;a href=&quot;http://sqlitebrowser.org&quot;&gt;http://sqlitebrowser.org&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:small;&quot;&gt;This software uses the GPL/LGPL Qt Toolkit from &lt;/span&gt;&lt;a href=&quot;http://qt-project.org/&quot;&gt;&lt;span style=&quot; font-size:small;&quot;&gt;http://qt-project.org/&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:small;&quot;&gt;&lt;br/&gt;See &lt;/span&gt;&lt;a href=&quot;http://qt-project.org/doc/qt-5/licensing.html&quot;&gt;&lt;span style=&quot; font-size:small;&quot;&gt;http://qt-project.org/doc/qt-5/licensing.html&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:small;&quot;&gt; for licensing terms and information.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:small;&quot;&gt;It also uses the Silk icon set by Mark James licensed under a Creative Commons Attribution 2.5 and 3.0 license.&lt;br/&gt;See &lt;/span&gt;&lt;a href=&quot;http://www.famfamfam.com/lab/icons/silk/&quot;&gt;&lt;span style=&quot; font-size:small;&quot;&gt;http://www.famfamfam.com/lab/icons/silk/&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:small;&quot;&gt; for details.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Обозреватель для SQLite - это бесплатная программа, с открытым исходным кодом, предназначенная для создания и редактирования баз данных SQLite.&lt;/p&gt;&lt;p&gt;Программа лицензирована по двум лицензиям: Mozilla Public License Version 2 и GNU General Public License Version 3 or later. Можно изменять или распространять её на условиях этих лицензий.&lt;/p&gt;&lt;p&gt;Лицензии можно просмотреть по ссылкам &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.gnu.org/licenses/gpl.html&lt;/span&gt;&lt;/a&gt; и &lt;a href=&quot;https://www.mozilla.org/MPL/2.0/index.txt&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;https://www.mozilla.org/MPL/2.0/index.txt&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;Дополнительную информацию о программе можно узнать на веб-сайте:&lt;br/&gt;&lt;a href=&quot;https://sqlitebrowser.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;https://sqlitebrowser.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:small;&quot;&gt;Это программное обеспечение использует GPL/LGPL Qt Toolkit &lt;/span&gt;&lt;a href=&quot;http://qt-project.org/&quot;&gt;&lt;span style=&quot; font-size:small; text-decoration: underline; color:#0000ff;&quot;&gt;http://qt-project.org/&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:small;&quot;&gt;&lt;br/&gt;Условия лицензии на Qt Toolkit &lt;/span&gt;&lt;a href=&quot;http://qt-project.org/doc/qt-5/licensing.html&quot;&gt;&lt;span style=&quot; font-size:small; text-decoration: underline; color:#0000ff;&quot;&gt;http://qt-project.org/doc/qt-5/licensing.html&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:small;&quot;&gt;.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:small;&quot;&gt;Эта программа также использует набор иконок Silk от Марка Джеймса (Mark James), лицензированный под лицензией Creative Commons Attribution 2.5 and 3.0.&lt;br/&gt;Подробная информация по адресу &lt;/span&gt;&lt;a href=&quot;http://www.famfamfam.com/lab/icons/silk/&quot;&gt;&lt;span style=&quot; font-size:small; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.famfamfam.com/lab/icons/silk/&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:small;&quot;&gt;.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;DB Browser for SQLite is an open source, freeware visual tool used to create, design and edit SQLite database files.&lt;/p&gt;&lt;p&gt;It is bi-licensed under the Mozilla Public License Version 2, as well as the GNU General Public License Version 3 or later. You can modify or redistribute it under the conditions of these licenses.&lt;/p&gt;&lt;p&gt;See &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.gnu.org/licenses/gpl.html&lt;/span&gt;&lt;/a&gt; and &lt;a href=&quot;https://www.mozilla.org/MPL/2.0/index.txt&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;https://www.mozilla.org/MPL/2.0/index.txt&lt;/span&gt;&lt;/a&gt; for details.&lt;/p&gt;&lt;p&gt;For more information on this program please visit our website at: &lt;a href=&quot;https://sqlitebrowser.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;https://sqlitebrowser.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:small;&quot;&gt;This software uses the GPL/LGPL Qt Toolkit from &lt;/span&gt;&lt;a href=&quot;http://qt-project.org/&quot;&gt;&lt;span style=&quot; font-size:small; text-decoration: underline; color:#0000ff;&quot;&gt;http://qt-project.org/&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:small;&quot;&gt;&lt;br/&gt;See &lt;/span&gt;&lt;a href=&quot;http://qt-project.org/doc/qt-5/licensing.html&quot;&gt;&lt;span style=&quot; font-size:small; text-decoration: underline; color:#0000ff;&quot;&gt;http://qt-project.org/doc/qt-5/licensing.html&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:small;&quot;&gt; for licensing terms and information.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:small;&quot;&gt;It also uses the Silk icon set by Mark James licensed under a Creative Commons Attribution 2.5 and 3.0 license.&lt;br/&gt;See &lt;/span&gt;&lt;a href=&quot;http://www.famfamfam.com/lab/icons/silk/&quot;&gt;&lt;span style=&quot; font-size:small; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.famfamfam.com/lab/icons/silk/&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:small;&quot;&gt; for details.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Обозреватель для SQLite - это бесплатная программа, с открытым исходным кодом, предназначенная для создания и редактирования баз данных SQLite.&lt;/p&gt;&lt;p&gt;Программа лицензирована по двум лицензиям: Mozilla Public License Version 2 и GNU General Public License Version 3 or later. Можно изменять или распространять её на условиях этих лицензий.&lt;/p&gt;&lt;p&gt;Лицензии можно просмотреть по ссылкам &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.gnu.org/licenses/gpl.html&lt;/span&gt;&lt;/a&gt; и &lt;a href=&quot;https://www.mozilla.org/MPL/2.0/index.txt&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;https://www.mozilla.org/MPL/2.0/index.txt&lt;/span&gt;&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;Дополнительную информацию о программе можно узнать на веб-сайте:&lt;br/&gt;&lt;a href=&quot;https://sqlitebrowser.org&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;https://sqlitebrowser.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:small;&quot;&gt;Это программное обеспечение использует GPL/LGPL Qt Toolkit &lt;/span&gt;&lt;a href=&quot;http://qt-project.org/&quot;&gt;&lt;span style=&quot; font-size:small; text-decoration: underline; color:#0000ff;&quot;&gt;http://qt-project.org/&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:small;&quot;&gt;&lt;br/&gt;Условия лицензии на Qt Toolkit &lt;/span&gt;&lt;a href=&quot;http://qt-project.org/doc/qt-5/licensing.html&quot;&gt;&lt;span style=&quot; font-size:small; text-decoration: underline; color:#0000ff;&quot;&gt;http://qt-project.org/doc/qt-5/licensing.html&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:small;&quot;&gt;.&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:small;&quot;&gt;Эта программа также использует набор иконок Silk от Марка Джеймса (Mark James), лицензированный под лицензией Creative Commons Attribution 2.5 and 3.0.&lt;br/&gt;Подробная информация по адресу &lt;/span&gt;&lt;a href=&quot;http://www.famfamfam.com/lab/icons/silk/&quot;&gt;&lt;span style=&quot; font-size:small; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.famfamfam.com/lab/icons/silk/&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:small;&quot;&gt;.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../AboutDialog.cpp" line="19"/>
        <source> (based on SQLite %1)</source>
        <translation> (базируется на SQLite %1)</translation>
    </message>
    <message>
        <location filename="../AboutDialog.cpp" line="21"/>
        <source>Version </source>
        <translation>Версия </translation>
    </message>
    <message>
        <location filename="../AboutDialog.cpp" line="22"/>
        <source>Qt Version </source>
        <translation>Версия Qt </translation>
    </message>
    <message>
        <location filename="../AboutDialog.cpp" line="19"/>
        <source>SQLCipher Version </source>
        <translation>Версия SQLCipher </translation>
    </message>
    <message>
        <location filename="../AboutDialog.cpp" line="17"/>
        <source>SQLite Version </source>
        <translation>Версия SQLite </translation>
    </message>
</context>
<context>
    <name>AddRecordDialog</name>
    <message>
        <location filename="../AddRecordDialog.ui" line="14"/>
        <source>Add New Record</source>
        <translation>Добавить Новую Запись</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.ui" line="27"/>
        <source>Enter values for the new record considering constraints. Fields in bold are mandatory.</source>
        <translation>Введите значения для новой записи с учетом ограничений. Поля, выделенные жирным шрифтом, являются обязательными.</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.ui" line="67"/>
        <source>In the Value column you can specify the value for the field identified in the Name column. The Type column indicates the type of the field. Default values are displayed in the same style as NULL values.</source>
        <translation>В столбце &quot;Значение&quot; вы можете указать значение для поля, указанного в столбце &quot;Имя&quot;. В столбце &quot;Тип&quot; указывается тип поля. Значения по умолчанию отображаются в том же стиле, что и значения NULL.</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.ui" line="74"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.ui" line="79"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.ui" line="84"/>
        <source>Value</source>
        <translation>Значение</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.ui" line="87"/>
        <source>Values to insert. Pre-filled default values are inserted automatically unless they are changed.</source>
        <translation>Значения для вставки. Предварительно заполненные значения по умолчанию вставляются автоматически, если они не изменены.</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.ui" line="93"/>
        <source>When you edit the values in the upper frame, the SQL query for inserting this new record is shown here. You can edit manually the query before saving.</source>
        <translation>Когда вы редактируете значения в верхнем фрейме, здесь отображается запрос SQL для вставки этой новой записи. Вы можете вручную отредактировать запрос перед сохранением.</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.ui" line="110"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save&lt;/span&gt; will submit the shown SQL statement to the database for inserting the new record.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Restore Defaults&lt;/span&gt; will restore the initial values in the &lt;span style=&quot; font-weight:600;&quot;&gt;Value&lt;/span&gt; column.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cancel&lt;/span&gt; will close this dialog without executing the query.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Сохранение&lt;/span&gt; отправит показанный оператор SQL в БД для вставки новой записи.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Восстановить значения по умолчанию&lt;/span&gt; восстановит исходные значения в колонке &lt;span style=&quot; font-weight:600;&quot;&gt;Значение&lt;/span&gt;.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Отмена&lt;/span&gt; закрывает этот диалог без выполнения запросов.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.cpp" line="208"/>
        <source>Auto-increment
</source>
        <translation>Авто-увеличение
</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.cpp" line="211"/>
        <source>Unique constraint
</source>
        <translation>Уникальнось
</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.cpp" line="214"/>
        <source>Check constraint:	 %1
</source>
        <translation>Проверка:	 %1
</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.cpp" line="218"/>
        <source>Foreign key:	 %1
</source>
        <translation>Внешний ключ:	 %1
</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.cpp" line="226"/>
        <source>Default value:	 %1
</source>
        <translation>Значение по умолчанию:	 %1
</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.cpp" line="252"/>
        <source>Error adding record. Message from database engine:

%1</source>
        <translation>Ошибка добавления записи. Сообщение из базы данных:

%1</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.cpp" line="333"/>
        <source>Are you sure you want to restore all the entered values to their defaults?</source>
        <translation>Вы действительно хотите восстановить все введенные значения по умолчанию?</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../Application.cpp" line="86"/>
        <source>Usage: %1 [options] [db]
</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="87"/>
        <source>Possible command line arguments:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="88"/>
        <source>  -h, --help		Show command line options</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="90"/>
        <source>  -s, --sql [file]	Execute this SQL file after opening the DB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="91"/>
        <source>  -t, --table [table]	Browse this table after opening the DB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="97"/>
        <source>This is DB Browser for SQLite version %1.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="89"/>
        <source>  -q, --quit		Exit application after running scripts</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="92"/>
        <source>  -R, --read-only	Open database in read-only mode</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="93"/>
        <source>  -o, --option [group/setting=value]	Run application with this setting temporarily set to value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="94"/>
        <source>  -v, --version		Display the current version</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="94"/>
        <source>  [file]		Open this SQLite database</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="102"/>
        <source>The -s/--sql option requires an argument</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="104"/>
        <source>The file %1 does not exist</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="109"/>
        <source>The -t/--table option requires an argument</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="118"/>
        <source>The -o/--option option requires an argument in the form group/setting=value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Application.cpp" line="138"/>
        <source>Invalid option/non-existant file: %1</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>CipherDialog</name>
    <message>
        <location filename="../CipherDialog.ui" line="14"/>
        <source>SQLCipher encryption</source>
        <translation>Шифрование SQLCipher</translation>
    </message>
    <message>
        <location filename="../CipherDialog.ui" line="27"/>
        <source>&amp;Password</source>
        <translation>&amp;Пароль</translation>
    </message>
    <message>
        <location filename="../CipherDialog.ui" line="44"/>
        <source>&amp;Reenter password</source>
        <translation>Пароль &amp;ещё раз</translation>
    </message>
    <message>
        <location filename="../CipherDialog.ui" line="61"/>
        <source>Page si&amp;ze</source>
        <translation>Размер &amp;страницы</translation>
    </message>
    <message>
        <location filename="../CipherDialog.ui" line="79"/>
        <source>Passphrase</source>
        <translation>Фраза</translation>
    </message>
    <message>
        <location filename="../CipherDialog.ui" line="84"/>
        <source>Raw key</source>
        <translation>Ключ</translation>
    </message>
    <message>
        <source>Page &amp;size</source>
        <translation type="vanished">Размер &amp;страницы</translation>
    </message>
    <message>
        <location filename="../CipherDialog.cpp" line="34"/>
        <source>Please set a key to encrypt the database.
Note that if you change any of the other, optional, settings you&apos;ll need to re-enter them as well every time you open the database file.
Leave the password fields empty to disable the encryption.
The encryption process might take some time and you should have a backup copy of your database! Unsaved changes are applied before modifying the encryption.</source>
        <translation>Пожалуйста укажите ключ шифрования.
Если вы измените какую-либо опциональную настройку, то ее нужно будет вводить при каждом открытии этого файла базы данных.
Оставьте пароль пустым если шифрование не требуется.
Процесс может занять некоторое время и настоятельно рекомендуем создать резервную копию перед продолжением! Не сохраненные изменения автоматически будут сохранены.</translation>
    </message>
    <message>
        <location filename="../CipherDialog.cpp" line="39"/>
        <source>Please enter the key used to encrypt the database.
If any of the other settings were altered for this database file you need to provide this information as well.</source>
        <translation>Пожалуйста введите ключ для шифрования базы данных.
Если любые другие настройки были изменены для данной базы данный то нужно так же предоставить данную информацию.</translation>
    </message>
</context>
<context>
    <name>ColumnDisplayFormatDialog</name>
    <message>
        <location filename="../ColumnDisplayFormatDialog.ui" line="14"/>
        <source>Choose display format</source>
        <translation>Выберите формат отображения</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.ui" line="20"/>
        <source>Display format</source>
        <translation>Формат отображения</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.ui" line="26"/>
        <source>Choose a display format for the column &apos;%1&apos; which is applied to each value prior to showing it.</source>
        <translation>Выберите формат отображения для колонки &apos;%1&apos;, который будет применен к каждому ее значению.</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="12"/>
        <source>Default</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="14"/>
        <source>Decimal number</source>
        <translation>Десятичное число</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="15"/>
        <source>Exponent notation</source>
        <translation>Экспоненциальная запись</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="16"/>
        <source>Hex blob</source>
        <translation>Бинарные данные</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="17"/>
        <source>Hex number</source>
        <translation>Шестнадцатеричное число</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="21"/>
        <source>Apple NSDate to date</source>
        <translation>Apple NSDate дата</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="22"/>
        <source>Java epoch (milliseconds) to date</source>
        <translation>Java epoch дата</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="23"/>
        <source>Julian day to date</source>
        <translation>Юлианская дата</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="25"/>
        <source>Unix epoch to local time</source>
        <translation>Unix-время</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="27"/>
        <source>Date as dd/mm/yyyy</source>
        <translation>Дата в формате дд/мм/гггг</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="29"/>
        <source>Lower case</source>
        <translation>Нижний регистр</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="18"/>
        <source>Octal number</source>
        <translation>Восьмеричное число</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="19"/>
        <source>Round number</source>
        <translation>Округленное число</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="24"/>
        <source>Unix epoch to date</source>
        <translation>Unix-дата</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="30"/>
        <source>Upper case</source>
        <translation>Верхний регистр</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="26"/>
        <source>Windows DATE to date</source>
        <translation>Windows дата</translation>
    </message>
    <message>
        <location filename="../ColumnDisplayFormatDialog.cpp" line="66"/>
        <source>Custom</source>
        <translation>Мой формат</translation>
    </message>
</context>
<context>
    <name>DBBrowserDB</name>
    <message>
        <location filename="../sqlitedb.cpp" line="215"/>
        <source>Please specify the database name under which you want to access the attached database</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="264"/>
        <source>Invalid file format</source>
        <translation>Ошибочный формат файла</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="581"/>
        <source>Do you want to save the changes made to the database file %1?</source>
        <translation>Сохранить сделанные изменения в файле базы данных %1?</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="683"/>
        <source>Exporting database to SQL file...</source>
        <translation>Экспорт базы данных в файл SQL...</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="684"/>
        <location filename="../sqlitedb.cpp" line="913"/>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="912"/>
        <source>Executing SQL...</source>
        <translation>Выполнить код SQL...</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="934"/>
        <source>Action cancelled.</source>
        <translation>Действие отменено.</translation>
    </message>
    <message>
        <source>Error in statement #%1: %2.
Aborting execution.</source>
        <translation type="vanished">Ошибка в операторе #%1: %2. Прерывание выполнения.</translation>
    </message>
    <message>
        <source>renameColumn: cannot find table %1.</source>
        <translation type="vanished">переименованиеСтолбца: невозможно найти таблицу %1.</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="204"/>
        <source>This database has already been attached. Its schema name is &apos;%1&apos;.</source>
        <translation>Эта БД уже присоединена. Имя ее схемы - &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="576"/>
        <source>Do you really want to close this temporary database? All data will be lost.</source>
        <translation>Вы действительно хотите закрыть эту временную БД? Все данные будут потеряны.</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="633"/>
        <source>The database is currently busy: </source>
        <translation>БД занята: </translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="634"/>
        <source>Do you want to abort that other operation?</source>
        <translation>Вы хотите отменить эту операцию?</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="850"/>
        <location filename="../sqlitedb.cpp" line="883"/>
        <source>No database file opened</source>
        <translation>Файл БД не открыт</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="963"/>
        <location filename="../sqlitedb.cpp" line="976"/>
        <source>Error in statement #%1: %2.
Aborting execution%3.</source>
        <translation>Ошибка в выражении #%1: %2.
Прерываем выполнение%3.</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="966"/>
        <location filename="../sqlitedb.cpp" line="979"/>
        <source> and rolling back</source>
        <translation> и отменяем</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1189"/>
        <source>Cannot delete this object</source>
        <translation>Не удается удалить этот объект</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1220"/>
        <source>Cannot set data on this object</source>
        <translation>Невозможно назначить данные для этого объекта</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1338"/>
        <source>A table with the name &apos;%1&apos; already exists in schema &apos;%2&apos;.</source>
        <translation>Таблица с именем &apos;%1&apos; уже существует в схеме &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1349"/>
        <source>renameColumn: cannot find column %1.</source>
        <translation>переименованиеСтолбца: невозможно найти столбец %1.</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1357"/>
        <source>renameColumn: creating savepoint failed. DB says: %1</source>
        <translation>переименованиеСтолбца: ошибка создания точки сохранения. БД говорит: %1</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1403"/>
        <source>renameColumn: creating new table failed. DB says: %1</source>
        <translation>переименованиеСтолбца: ошибка создания новой таблицы. БД говорит: %1</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1416"/>
        <source>renameColumn: copying data to new table failed. DB says:
%1</source>
        <translation>переименованиеСтолбца: ошибка копирования данных в новую таблицу. БД говорит:
%1</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1473"/>
        <source>renameColumn: deleting old table failed. DB says: %1</source>
        <translation>переименованиеСтолбца: ошибка удаления старой таблицы. БД говорит: %1</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1498"/>
        <source>Restoring some of the objects associated with this table failed. This is most likely because some column names changed. Here&apos;s the SQL statement which you might want to fix and execute manually:

</source>
        <translation>Ошибка восстановления некоторых объектов, ассоциированных с этой таблицей. Наиболее вероятная причина этого - изменение имён некоторых столбцов таблицы. Вот SQL оператор, который нужно исправить и выполнить вручную:

</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1507"/>
        <source>renameColumn: releasing savepoint failed. DB says: %1</source>
        <translation>переименованиеСтолбца: ошибока освобождения точки сохранения. БД говорит: %1</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1546"/>
        <source>Error renaming table &apos;%1&apos; to &apos;%2&apos;.Message from database engine:
%3</source>
        <translation>Ошибка переименования программы &apos;%1&apos; в &apos;%2&apos;.Сообщение от движка БД:
%3</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1581"/>
        <source>... &lt;string can not be logged, contains binary data&gt; ...</source>
        <translation>... &lt;строка не может быть залогирована, содержит двоичные данные&gt; ...</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1690"/>
        <source>could not get list of databases: %1</source>
        <translation>не могу получить список БД: %1</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1817"/>
        <source>Error loading extension: %1</source>
        <translation>Ошибка загрузки расширения: %1</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1842"/>
        <source>could not get column information</source>
        <translation>не могу полчить информацию о колонке</translation>
    </message>
    <message>
        <source>unknown object type %1</source>
        <translation type="vanished">неизвестный тип объекта %1</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1684"/>
        <source>could not get list of db objects: %1, %2</source>
        <translation>невозможно получить список объекто БД: %1, %2</translation>
    </message>
    <message>
        <source>could not get types</source>
        <translation type="vanished">невозможно получить типы</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1720"/>
        <source>didn&apos;t receive any output from pragma %1</source>
        <translation>не принято ни одного выхода из прагмы %1</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1724"/>
        <source>could not execute pragma command: %1, %2</source>
        <translation>невозможно выполнить комманду-прагму: %1, %2</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1745"/>
        <source>Error setting pragma %1 to %2: %3</source>
        <translation>Ошибка установки прагмы %1 в %2: %3</translation>
    </message>
    <message>
        <location filename="../sqlitedb.cpp" line="1791"/>
        <source>File not found.</source>
        <translation>Файл не найден.</translation>
    </message>
</context>
<context>
    <name>DbStructureModel</name>
    <message>
        <location filename="../DbStructureModel.cpp" line="19"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../DbStructureModel.cpp" line="19"/>
        <source>Object</source>
        <translation>Объект</translation>
    </message>
    <message>
        <location filename="../DbStructureModel.cpp" line="19"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../DbStructureModel.cpp" line="19"/>
        <source>Schema</source>
        <translation>Схема</translation>
    </message>
    <message>
        <source>Browsables (%1)</source>
        <translation type="vanished">Просматриваемые (%1)</translation>
    </message>
    <message>
        <location filename="../DbStructureModel.cpp" line="19"/>
        <source>Database</source>
        <translation>База данных</translation>
    </message>
    <message>
        <location filename="../DbStructureModel.cpp" line="154"/>
        <source>Browsables</source>
        <translation>Просматриваемые</translation>
    </message>
    <message>
        <location filename="../DbStructureModel.cpp" line="159"/>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="../DbStructureModel.cpp" line="168"/>
        <source>Temporary</source>
        <translation>Временный</translation>
    </message>
    <message>
        <location filename="../DbStructureModel.cpp" line="306"/>
        <source>Tables (%1)</source>
        <translation>Таблицы (%1)</translation>
    </message>
    <message>
        <location filename="../DbStructureModel.cpp" line="311"/>
        <source>Indices (%1)</source>
        <translation>Индексы (%1)</translation>
    </message>
    <message>
        <location filename="../DbStructureModel.cpp" line="316"/>
        <source>Views (%1)</source>
        <translation>Представления (%1)</translation>
    </message>
    <message>
        <location filename="../DbStructureModel.cpp" line="321"/>
        <source>Triggers (%1)</source>
        <translation>Триггеры (%1)</translation>
    </message>
</context>
<context>
    <name>EditDialog</name>
    <message>
        <location filename="../EditDialog.ui" line="14"/>
        <source>Edit database cell</source>
        <translation>Редактирование ячейки базы данных</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="28"/>
        <source>Mode:</source>
        <translation>Режим:</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="55"/>
        <source>Image</source>
        <translation>Изображение</translation>
    </message>
    <message>
        <source>Import text</source>
        <translation type="vanished">Импортировать текст</translation>
    </message>
    <message>
        <source>Opens a file dialog used to import text to this database cell.</source>
        <translation type="vanished">Открывается файловый диалог,  чтобы импортировать текств эту ячейку базы данных.</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="151"/>
        <source>&amp;Import</source>
        <translation>&amp;Импорт</translation>
    </message>
    <message>
        <source>Export text</source>
        <translation type="vanished">Экспортировать текст</translation>
    </message>
    <message>
        <source>Opens a file dialog used to export the contents of this database cell to a text file.</source>
        <translation type="vanished">Открывается файловый диалог, чтобы экспоритровать содержимое этой ячейки базы данных в текстовый файл.</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="170"/>
        <source>&amp;Export</source>
        <translation>&amp;Экспорт</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="183"/>
        <source>Set this cell to NULL</source>
        <translation>Присвоить данной ячейке NULL значение</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="189"/>
        <source>Set as &amp;NULL</source>
        <translation>Присвоить &amp;NULL</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="296"/>
        <source>Apply data to cell</source>
        <translation>Применить данные к ячейке</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="299"/>
        <source>This button saves the changes performed in the cell editor to the database cell.</source>
        <translation>Нажав эту кнопку, вы сохраните изменения произведенные в этом редакторе, в соответствующую ячейку БД.</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="302"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="45"/>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="41"/>
        <source>This is the list of supported modes for the cell editor. Choose a mode for viewing or editing the data of the current cell.</source>
        <translation>Это список поддерживаемых режимов. Выбирете режим для просмотра или редактирования данных текущей ячейки.</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="50"/>
        <source>Binary</source>
        <translation>Двоичные данные</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="60"/>
        <source>JSON</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="65"/>
        <source>XML</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="73"/>
        <location filename="../EditDialog.ui" line="76"/>
        <source>Automatically adjust the editor mode to the loaded data type</source>
        <translation>Автоматически подбор режима редактора на основе данных</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="79"/>
        <source>This checkable button enables or disables the automatic switching of the editor mode. When a new cell is selected or new data is imported and the automatic switching is enabled, the mode adjusts to the detected data type. You can then change the editor mode manually. If you want to keep this manually switched mode while moving through the cells, switch the button off.</source>
        <translation>Эта кнопка позволяет включать или отключать автоматическое переключение режима редактора. Когда выбрана новая ячейка или импортированы новые данные, а автоматическое переключение включено, режим настраивается на обнаруженный тип данных. Вы можете вручную изменить режим редактора. Если вы хотите сохранить этот режим ручного переключения при перемещении по ячейкам, выключите кнопку.</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="82"/>
        <source>Auto-switch</source>
        <translation>Автопереключение</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="116"/>
        <location filename="../EditDialog.ui" line="119"/>
        <source>Auto-format: pretty print on loading, compact on saving.</source>
        <translation>Автоматическое форматирование: стилистическое форматирование при загрузке, компактность - при сохранении.</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="122"/>
        <source>When enabled, the auto-format feature formats the data on loading, breaking the text in lines and indenting it for maximum readability. On data saving, the auto-format feature compacts the data removing end of lines, and unnecessary whitespace.</source>
        <translation>Когда включено, функция автоматического форматирования форматирует данные по загрузке, разбивая текст в строках и отступы для максимальной читаемости. При сохранении данных функция автоматического форматирования объединяет данные, удаляющие конец строк, и ненужные пробелы.</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="125"/>
        <source>Autoformat</source>
        <translation>Автоформатирование</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="145"/>
        <source>Import from file</source>
        <translation>Импортировать из файла</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="148"/>
        <source>Opens a file dialog used to import any kind of data to this database cell.</source>
        <translation>Открывает диалоговое окно файла, используемое для импорта любых данных в эту ячейку базы данных.</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="164"/>
        <source>Export to file</source>
        <translation>Экспортировать в файл</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="167"/>
        <source>Opens a file dialog used to export the contents of this database cell to a file.</source>
        <translation>Открывает диалоговое окно файла, используемое для экспорта содержимого этой ячейки базы данных в файл.</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="186"/>
        <source>Erases the contents of the cell</source>
        <translation>Очищается содержимое ячейки</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="210"/>
        <source>This area displays information about the data present in this database cell</source>
        <translation>Эта область отображает информацию о данных, находящихся в этой ячейке базы данных</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="253"/>
        <source>This editor mode lets you edit JSON or XML data with syntax highlighting, automatic formatting and validation before saving.

Errors are indicated with a red squiggle underline.</source>
        <translation>Этот режим редактора позволяет редактировать данные JSON или XML с подсветкой синтаксиса, автоматическим форматированием и проверкой перед сохранением.

Ошибки обозначаются красным подчеркиванием.</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="267"/>
        <source>Type of data currently in cell</source>
        <translation>Тип данных в ячейке</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="274"/>
        <source>Size of data currently in table</source>
        <translation>Размер данных в таблице</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="318"/>
        <location filename="../EditDialog.ui" line="333"/>
        <source>Print...</source>
        <translation>Печать...</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="321"/>
        <source>Open preview dialog for printing displayed image</source>
        <translation>Открыть диалоговое окно предварительного просмотра для печати отображаемого изображения</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="324"/>
        <location filename="../EditDialog.ui" line="339"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="336"/>
        <source>Open preview dialog for printing displayed text</source>
        <translation>Открыть диалоговое окно предварительного просмотра для печати отображаемого текста</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="348"/>
        <source>Copy Hex and ASCII</source>
        <translation>Копировать HEX и ASCII</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="351"/>
        <source>Copy selected hexadecimal and ASCII columns to the clipboard</source>
        <translation>Копировать выбранные HEX и ASCII столбцы в буфер обмена</translation>
    </message>
    <message>
        <location filename="../EditDialog.ui" line="354"/>
        <source>Ctrl+Shift+C</source>
        <translation></translation>
    </message>
    <message>
        <source>Choose a file</source>
        <translation type="vanished">Выбрать файл</translation>
    </message>
    <message>
        <source>Text files(*.txt);;Image files(%1);;All files(*)</source>
        <translation type="vanished">Текстовые файлы(*.txt);;Файлы изображений(%1);;Все файлы(*)</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="407"/>
        <source>Choose a filename to export data</source>
        <translation>Выбрать имя файла для экспорта данных</translation>
    </message>
    <message>
        <source>Text files(*.txt);;All files(*)</source>
        <translation type="vanished">Текстовые файлы(*.txt);;Все файлы(*)</translation>
    </message>
    <message>
        <source>Image data can&apos;t be viewed with the text editor</source>
        <translation type="vanished">Изображение не может быть отображено в текстовом редакторе</translation>
    </message>
    <message>
        <source>Binary data can&apos;t be viewed with the text editor</source>
        <translation type="vanished">Бинарные данные не могут быть отображены в текстовом редакторе</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="929"/>
        <source>Type of data currently in cell: %1 Image</source>
        <translation>Тип данных в ячейке: %1 Изображение</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="935"/>
        <source>%1x%2 pixel(s)</source>
        <translation>%1x%2 пикселей</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="946"/>
        <source>Type of data currently in cell: NULL</source>
        <translation>Тип данных в ячейке: NULL</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="765"/>
        <location filename="../EditDialog.cpp" line="956"/>
        <source>Type of data currently in cell: Text / Numeric</source>
        <translation>Тип данных в ячейке: Текст / Числовое</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="213"/>
        <location filename="../EditDialog.cpp" line="222"/>
        <source>Image data can&apos;t be viewed in this mode.</source>
        <translation>Изображение не может быть отображено в этом режиме.</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="214"/>
        <location filename="../EditDialog.cpp" line="223"/>
        <source>Try switching to Image or Binary mode.</source>
        <translation>Попробуйте переключиться в Бинарный режим или режим Изображения.</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="279"/>
        <location filename="../EditDialog.cpp" line="288"/>
        <source>Binary data can&apos;t be viewed in this mode.</source>
        <translation>Бинарные данные не могут быть отображены в этом режиме.</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="280"/>
        <location filename="../EditDialog.cpp" line="289"/>
        <source>Try switching to Binary mode.</source>
        <translation>Попробуйте переключиться в Бинарный режим.</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="312"/>
        <location filename="../EditDialog.cpp" line="326"/>
        <location filename="../EditDialog.cpp" line="385"/>
        <location filename="../EditDialog.cpp" line="387"/>
        <source>Text files (*.txt)</source>
        <translation>Текстовые файлы (*.txt)</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="313"/>
        <location filename="../EditDialog.cpp" line="335"/>
        <location filename="../EditDialog.cpp" line="390"/>
        <source>JSON files (*.json)</source>
        <translation>JSON файлы (*.json)</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="314"/>
        <location filename="../EditDialog.cpp" line="338"/>
        <location filename="../EditDialog.cpp" line="385"/>
        <location filename="../EditDialog.cpp" line="387"/>
        <source>XML files (*.xml)</source>
        <translation>XML файлы (*.xml)</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="315"/>
        <location filename="../EditDialog.cpp" line="332"/>
        <source>Image files (%1)</source>
        <translation>Файлы изображений (%1)</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="316"/>
        <location filename="../EditDialog.cpp" line="329"/>
        <location filename="../EditDialog.cpp" line="380"/>
        <source>Binary files (*.bin)</source>
        <translation>Бинарные файлы (*.bin)</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="316"/>
        <location filename="../EditDialog.cpp" line="402"/>
        <source>All files (*)</source>
        <translation>Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="343"/>
        <source>Choose a file to import</source>
        <translation>Выбрать файл для импорта</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="376"/>
        <source>%1 Image</source>
        <translation>%1 Изображение</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="393"/>
        <source>SVG files (*.svg)</source>
        <translation>SVG файлы (*.svg)</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="400"/>
        <location filename="../EditDialog.cpp" line="420"/>
        <source>Hex dump files (*.txt)</source>
        <translation>Файлы дампов (*.txt)</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="474"/>
        <source>Invalid data for this mode</source>
        <translation>Ошибочные данные для этого режима</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="475"/>
        <source>The cell contains invalid %1 data. Reason: %2. Do you really want to apply it to the cell?</source>
        <translation>Ячейка содержит ошибочные %1 данные. Причина: %2. Вы действительно хотите применить их?</translation>
    </message>
    <message numerus="yes">
        <location filename="../EditDialog.cpp" line="767"/>
        <location filename="../EditDialog.cpp" line="957"/>
        <location filename="../EditDialog.cpp" line="965"/>
        <source>%n character(s)</source>
        <translation>
            <numerusform>%n символ</numerusform>
            <numerusform>%n символа</numerusform>
            <numerusform>%n символов</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="964"/>
        <source>Type of data currently in cell: Valid JSON</source>
        <translation>Тип данных в ячейке: JSON</translation>
    </message>
    <message>
        <location filename="../EditDialog.cpp" line="973"/>
        <source>Type of data currently in cell: Binary</source>
        <translation>Тип данных в ячейке: Двоичные данные</translation>
    </message>
    <message numerus="yes">
        <location filename="../EditDialog.cpp" line="947"/>
        <location filename="../EditDialog.cpp" line="974"/>
        <source>%n byte(s)</source>
        <translation>
            <numerusform>%n байт</numerusform>
            <numerusform>%n байта</numerusform>
            <numerusform>%n байтов</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>EditIndexDialog</name>
    <message>
        <source>Create New Index</source>
        <translation type="vanished">Создание нового индекса</translation>
    </message>
    <message>
        <location filename="../EditIndexDialog.ui" line="26"/>
        <source>&amp;Name</source>
        <translation>&amp;Имя</translation>
    </message>
    <message>
        <source>&amp;Columns</source>
        <translation type="vanished">&amp;Столбцы</translation>
    </message>
    <message>
        <source>Column</source>
        <translation type="vanished">Столбец</translation>
    </message>
    <message>
        <source>Use in Index</source>
        <translation type="vanished">Использовать в индексе</translation>
    </message>
    <message>
        <location filename="../EditIndexDialog.ui" line="237"/>
        <source>Order</source>
        <translation>Сортировка</translation>
    </message>
    <message>
        <location filename="../EditIndexDialog.ui" line="39"/>
        <source>&amp;Table</source>
        <translation>&amp;Таблица</translation>
    </message>
    <message>
        <location filename="../EditIndexDialog.ui" line="14"/>
        <source>Edit Index Schema</source>
        <translation>Редактирование Индекса</translation>
    </message>
    <message>
        <location filename="../EditIndexDialog.ui" line="52"/>
        <source>&amp;Unique</source>
        <translation>&amp;Уникальный</translation>
    </message>
    <message>
        <location filename="../EditIndexDialog.ui" line="69"/>
        <source>For restricting the index to only a part of the table you can specify a WHERE clause here that selects the part of the table that should be indexed</source>
        <translation>Для ограничения индекса только частью таблицы вы можете указать здесь выражение WHERE, которое выбирает часть таблицы, которая должна быть проиндексирована</translation>
    </message>
    <message>
        <location filename="../EditIndexDialog.ui" line="72"/>
        <source>Partial inde&amp;x clause</source>
        <translation>&amp;Частичный индекс</translation>
    </message>
    <message>
        <location filename="../EditIndexDialog.ui" line="85"/>
        <source>Colu&amp;mns</source>
        <translation>&amp;Колонки</translation>
    </message>
    <message>
        <location filename="../EditIndexDialog.ui" line="130"/>
        <source>Table column</source>
        <translation>Колонка таблицы</translation>
    </message>
    <message>
        <location filename="../EditIndexDialog.ui" line="135"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../EditIndexDialog.ui" line="172"/>
        <source>Add a new expression column to the index. Expression columns contain SQL expression rather than column names.</source>
        <translation>Добавить новое колоночное-выражение в индекс. Колоночное выражение может содержкать SQL выражения вместо имен колонок.</translation>
    </message>
    <message>
        <location filename="../EditIndexDialog.ui" line="232"/>
        <source>Index column</source>
        <translation>Колонка индекса</translation>
    </message>
    <message>
        <location filename="../EditIndexDialog.cpp" line="268"/>
        <source>Deleting the old index failed:
%1</source>
        <translation>Удаление старого индекса завершилось с ошибкой:
%1</translation>
    </message>
    <message>
        <location filename="../EditIndexDialog.cpp" line="277"/>
        <source>Creating the index failed:
%1</source>
        <translation>Ошибка создания индекса:
%1</translation>
    </message>
</context>
<context>
    <name>EditTableDialog</name>
    <message>
        <location filename="../EditTableDialog.ui" line="14"/>
        <source>Edit table definition</source>
        <translation>Редактирование определения таблицы</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="27"/>
        <source>Table</source>
        <translation>Таблица</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="43"/>
        <source>Advanced</source>
        <translation>Дополнительно</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="62"/>
        <source>Database schema</source>
        <translation>Схема БД</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="85"/>
        <source>Make this a &apos;WITHOUT rowid&apos; table. Setting this flag requires a field of type INTEGER with the primary key flag set and the auto increment flag unset.</source>
        <translation>Чтобы создать таблицу &apos;без rowid&apos;, нужно чтобы в ней был INTEGER первичный ключ с отключенным автоинкрементом.</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="75"/>
        <source>Without Rowid</source>
        <translation>Без rowid</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="98"/>
        <source>Fields</source>
        <translation>Поля</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="106"/>
        <source>Add field</source>
        <translation>Добавить поле</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="126"/>
        <source>Remove field</source>
        <translation>Удалить поле</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="146"/>
        <source>Move field up</source>
        <translation>Переместить поле вверх</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="166"/>
        <source>Move field down</source>
        <translation>Переместить поле вниз</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="236"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="241"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="246"/>
        <source>NN</source>
        <translation>НП</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="249"/>
        <source>Not null</source>
        <translation>Не пустое (null)</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="254"/>
        <source>PK</source>
        <translation>ПК</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="257"/>
        <source>Primary key</source>
        <translation>Первичный ключ</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="262"/>
        <source>AI</source>
        <translation>АИ</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="265"/>
        <source>Autoincrement</source>
        <translation>Автоинкремент</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="270"/>
        <source>U</source>
        <translation>У</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="273"/>
        <source>Unique</source>
        <translation>Уникальное</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="278"/>
        <source>Default</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="281"/>
        <source>Default value</source>
        <translation>Значение по умолчанию</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="286"/>
        <source>Check</source>
        <translation>Проверить</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="289"/>
        <source>Check constraint</source>
        <translation>Проверить ограничение</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="294"/>
        <source>Foreign Key</source>
        <translation>Внешний ключ</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.ui" line="314"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600; color:#ff0000;&quot;&gt;Warning: &lt;/span&gt;There is something with this table definition that our parser doesn&apos;t fully understand. Modifying and saving this table might result in problems.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600; color:#ff0000;&quot;&gt;Внимание: &lt;/span&gt;В описании этой таблицы есть что-то, что наш парсер не понимает. Модификация и сохрание этой таблицы может породить проблемы.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600; color:#ff0000;&quot;&gt;Warning: &lt;/span&gt;There is something with this table definition that our parser doesn&apos;t fully understand. Modifying and saving this table might result it in problems.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600; color:#ff0000;&quot;&gt;Внимание: &lt;/span&gt;Определение данной таблицы наш парсер не смог понять. Eё модификация и сохранение может привести к последующим проблемам.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.cpp" line="167"/>
        <source>Error creating table. Message from database engine:
%1</source>
        <translation>Ошибка создания таблицы. Сообщение от движка базы данных: %1</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.cpp" line="291"/>
        <source>There already is a field with that name. Please rename it first or choose a different name for this field.</source>
        <translation>Поле с таким именем уже существует. Пожалуйста переименуйте его, либо выберите другое имя для данного поля.</translation>
    </message>
    <message>
        <source>This column is referenced in a foreign key in table %1, column %2 and thus its name cannot be changed.</source>
        <translation type="obsolete">На данную колонку ссылкается внешний ключ в таблице %1, поле %2 поэтому ее имя не может быть изменено.</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.cpp" line="314"/>
        <source>This column is referenced in a foreign key in table %1 and thus its name cannot be changed.</source>
        <translation>На данную колонку ссылкается внешний ключ в таблице %1, поэтому ее имя не может быть изменено.</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.cpp" line="391"/>
        <source>There is at least one row with this field set to NULL. This makes it impossible to set this flag. Please change the table data first.</source>
        <translation>Существует по крайней мере одна строка, где это поле установлено в NULL. Установить этот флаг нельзя. Сначала измените данные таблицы.</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.cpp" line="424"/>
        <source>There is at least one row with a non-integer value in this field. This makes it impossible to set the AI flag. Please change the table data first.</source>
        <translation>Существует по крайней мере одна строка, где это поле содержит нечисловое значение. Установить флаг АИ нельзя. Сначала измените данные таблицы.</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.cpp" line="480"/>
        <source>Column &apos;%1&apos; has no unique data.
</source>
        <translation>Колонка &apos;%1&apos; не содержит уникальных данных.
</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.cpp" line="481"/>
        <source>This makes it impossible to set this flag. Please change the table data first.</source>
        <translation>Невозможно. Для начала, измените данные таблицы.</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.cpp" line="540"/>
        <source>Modifying this column failed. Error returned from database:
%1</source>
        <translation>Модификация этой колонки завершилась с ошибкой:
%1</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.cpp" line="619"/>
        <source>Are you sure you want to delete the field &apos;%1&apos;?
All data currently stored in this field will be lost.</source>
        <translation>Удалить поле &apos;%1&apos;?
Все данные, которые в настоящий момент сохранены в этом поле, будут потеряны.</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.cpp" line="730"/>
        <source>Please add a field which meets the following criteria before setting the without rowid flag:
 - Primary key flag set
 - Auto increment disabled</source>
        <translation>Перед тем как применять флаг без rowid, пожалуйста убедитесь, что существует столбец, который:
 - является первичный ключом
 - для него отключен автоинкремент</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.cpp" line="758"/>
        <source>Setting the rowid column for the table failed. Error message:
%1</source>
        <translation>Назначение rowid колонки завершилось с ошибкой:
%1</translation>
    </message>
    <message>
        <location filename="../EditTableDialog.cpp" line="776"/>
        <source>Changing the table schema failed. Error message:
%1</source>
        <translation>Изменение схемы таблицы завершилось с ошибкой:
%1</translation>
    </message>
</context>
<context>
    <name>ExportDataDialog</name>
    <message>
        <location filename="../ExportDataDialog.ui" line="14"/>
        <source>Export data as CSV</source>
        <translation>Экспортировать данные в формате CSV</translation>
    </message>
    <message>
        <source>&amp;Table(s)</source>
        <translation type="obsolete">&amp;Таблицы</translation>
    </message>
    <message>
        <source>&amp;Column names in first line</source>
        <translation type="obsolete">&amp;Имена столбцов в первой строке</translation>
    </message>
    <message>
        <source>Field &amp;separator</source>
        <translation type="obsolete">&amp;Разделитель полей</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="22"/>
        <source>Tab&amp;le(s)</source>
        <translation>&amp;Таблицы</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="57"/>
        <source>Colu&amp;mn names in first line</source>
        <translation>&amp;Имена столбцов в первой строке</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="77"/>
        <source>Fie&amp;ld separator</source>
        <translation>&amp;Разделитель полей</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="102"/>
        <source>,</source>
        <translation>,</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="107"/>
        <source>;</source>
        <translation>;</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="112"/>
        <source>Tab</source>
        <translation>Табуляция</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="117"/>
        <source>|</source>
        <translation>|</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="122"/>
        <location filename="../ExportDataDialog.ui" line="192"/>
        <location filename="../ExportDataDialog.ui" line="254"/>
        <source>Other</source>
        <translation>Другой</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="152"/>
        <source>&amp;Quote character</source>
        <translation>&amp;Символ кавычки</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="177"/>
        <source>&quot;</source>
        <translation>&quot;</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="182"/>
        <source>&apos;</source>
        <translation>&apos;</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="222"/>
        <source>New line characters</source>
        <translation>Разделитель строк</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="244"/>
        <source>Windows: CR+LF (\r\n)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="249"/>
        <source>Unix: LF (\n)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.ui" line="288"/>
        <source>Pretty print</source>
        <translation>Красивый вывод</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.cpp" line="188"/>
        <location filename="../ExportDataDialog.cpp" line="283"/>
        <source>Could not open output file: %1</source>
        <translation>Не удалось открыть выходной файл: %1</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.cpp" line="311"/>
        <location filename="../ExportDataDialog.cpp" line="337"/>
        <source>Choose a filename to export data</source>
        <translation>Выберите имя файла для экспорта данных</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.cpp" line="297"/>
        <source>Text files(*.csv *.txt)</source>
        <translation>Текстовые файлы(*.csv *.txt)</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.cpp" line="29"/>
        <source>Export data as JSON</source>
        <translation>Экспортировать данные как JSON</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.cpp" line="120"/>
        <source>exporting CSV</source>
        <translation>экспортирование CSV</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.cpp" line="204"/>
        <source>exporting JSON</source>
        <translation>экспортирование JSON</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.cpp" line="301"/>
        <source>Text files(*.json *.js *.txt)</source>
        <translation>Текстовые файлы (*.json *.js *.txt)</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.cpp" line="327"/>
        <source>Please select at least 1 table.</source>
        <translation>Пожалуйста, выберите хотя бы одну таблицу.</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.cpp" line="351"/>
        <source>Choose a directory</source>
        <translation>Выберать каталог</translation>
    </message>
    <message>
        <location filename="../ExportDataDialog.cpp" line="382"/>
        <source>Export completed.</source>
        <translation>Экспорт завершён.</translation>
    </message>
</context>
<context>
    <name>ExportSqlDialog</name>
    <message>
        <location filename="../ExportSqlDialog.ui" line="14"/>
        <source>Export SQL...</source>
        <translation>Экспорт SQL....</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.ui" line="35"/>
        <source>Tab&amp;le(s)</source>
        <translation>&amp;Таблицы</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.ui" line="63"/>
        <source>Select All</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.ui" line="70"/>
        <source>Deselect All</source>
        <translation>Отменить выбор</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.ui" line="79"/>
        <source>&amp;Options</source>
        <translation>&amp;Опции</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.ui" line="85"/>
        <source>Keep column names in INSERT INTO</source>
        <translation>Имя столбцов в выражении INSERT INTO</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.ui" line="95"/>
        <source>Multiple rows (VALUES) per INSERT statement</source>
        <translation>Несколько строк (VALUES) на INSERT выражение</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.ui" line="116"/>
        <source>Export everything</source>
        <translation>Экспортировать все</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.ui" line="126"/>
        <source>Export data only</source>
        <translation>Экспортировать только данные</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.ui" line="135"/>
        <source>Keep old schema (CREATE TABLE IF NOT EXISTS)</source>
        <translation>Проверять существоватние таблицы (CREATE TABLE IF NOT EXISTS)</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.ui" line="140"/>
        <source>Overwrite old schema (DROP TABLE, then CREATE TABLE)</source>
        <translation>Удалять старую таблицу перед созданием (DROP TABLE, затем CREATE TABLE)</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.ui" line="121"/>
        <source>Export schema only</source>
        <translation>Экспортировать только схему данных</translation>
    </message>
    <message>
        <source>Please select at least 1 table.</source>
        <translation type="vanished">Пожалуйста, выберите хотя бы одну таблицу.</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.cpp" line="74"/>
        <source>Please select at least one table.</source>
        <translation>Пожалуйста, выберите хотя бы одну таблицу.</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.cpp" line="87"/>
        <source>Choose a filename to export</source>
        <translation>Выберите имя файла для экспорта</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.cpp" line="88"/>
        <source>Text files(*.sql *.txt)</source>
        <translation>Текстовые файлы(*.sql *.txt)</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.cpp" line="116"/>
        <source>Export completed.</source>
        <translation>Экспорт завершён.</translation>
    </message>
    <message>
        <location filename="../ExportSqlDialog.cpp" line="118"/>
        <source>Export cancelled or failed.</source>
        <translation>Экспорт отменён или возникли ошибки.</translation>
    </message>
</context>
<context>
    <name>ExtendedScintilla</name>
    <message>
        <location filename="../ExtendedScintilla.cpp" line="58"/>
        <location filename="../ExtendedScintilla.cpp" line="232"/>
        <source>Ctrl+H</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ExtendedScintilla.cpp" line="61"/>
        <location filename="../ExtendedScintilla.cpp" line="236"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../ExtendedScintilla.cpp" line="231"/>
        <source>Find and Replace...</source>
        <translation>Найти и Заменить...</translation>
    </message>
    <message>
        <location filename="../ExtendedScintilla.cpp" line="235"/>
        <source>Print...</source>
        <translation>Печать...</translation>
    </message>
</context>
<context>
    <name>ExtendedTableWidget</name>
    <message>
        <source>The content of clipboard is bigger than the range selected.
Do you want to insert it anyway?</source>
        <translation type="vanished">Содержимое буфера обмена больше чем выбранный диапазон.
Все равно вставить?</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="195"/>
        <source>Use as Exact Filter</source>
        <translation>Использовать как Точный Фильтр</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="196"/>
        <source>Containing</source>
        <translation>Содержит</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="197"/>
        <source>Not equal to</source>
        <translation>Не равно</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="198"/>
        <source>Greater than</source>
        <translation>Больше чем</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="199"/>
        <source>Less than</source>
        <translation>Меньше чем</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="200"/>
        <source>Greater or equal</source>
        <translation>Больше или равно</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="201"/>
        <source>Less or equal</source>
        <translation>Меньше или равно</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="202"/>
        <source>Between this and...</source>
        <translation>Между этим и...</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="204"/>
        <source>Set to NULL</source>
        <translation>Сбросить в NULL</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="205"/>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="206"/>
        <source>Copy with Headers</source>
        <translation>Копировать с заголовками</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="207"/>
        <source>Copy as SQL</source>
        <translation>Копировать как SQL</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="208"/>
        <source>Paste</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="209"/>
        <source>Print...</source>
        <translation>Печать...</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="212"/>
        <source>Use in Filter Expression</source>
        <translation>Использовать в Выражении Фильтра</translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="238"/>
        <source>Alt+Del</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="240"/>
        <source>Ctrl+Shift+C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="241"/>
        <source>Ctrl+Alt+C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ExtendedTableWidget.cpp" line="584"/>
        <source>The content of the clipboard is bigger than the range selected.
Do you want to insert it anyway?</source>
        <translation>Содержимое буфера обмена больше чем выделенный диапозон.
Все равно вставить?</translation>
    </message>
</context>
<context>
    <name>FileDialog</name>
    <message>
        <source>SQLite database files (*.db *.sqlite *.sqlite3 *.db3);;All files (*)</source>
        <translation type="vanished">Файлы SQLite баз данных (*.db *.sqlite *.sqlite3 *.db3);;Все файлы (*)</translation>
    </message>
</context>
<context>
    <name>FileExtensionManager</name>
    <message>
        <location filename="../FileExtensionManager.ui" line="14"/>
        <source>File Extension Manager</source>
        <translation>Менеджер расширения файлов</translation>
    </message>
    <message>
        <location filename="../FileExtensionManager.ui" line="22"/>
        <source>&amp;Up</source>
        <translation>&amp;Выше</translation>
    </message>
    <message>
        <location filename="../FileExtensionManager.ui" line="33"/>
        <source>&amp;Down</source>
        <translation>&amp;Ниже</translation>
    </message>
    <message>
        <location filename="../FileExtensionManager.ui" line="57"/>
        <source>&amp;Add</source>
        <translation>&amp;Добавить</translation>
    </message>
    <message>
        <location filename="../FileExtensionManager.ui" line="68"/>
        <source>&amp;Remove</source>
        <translation>&amp;Удалить</translation>
    </message>
    <message>
        <location filename="../FileExtensionManager.ui" line="94"/>
        <location filename="../FileExtensionManager.cpp" line="41"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <location filename="../FileExtensionManager.ui" line="99"/>
        <source>Extensions</source>
        <translation>Расширения</translation>
    </message>
    <message>
        <location filename="../FileExtensionManager.cpp" line="42"/>
        <source>*.extension</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>FilterLineEdit</name>
    <message>
        <location filename="../FilterLineEdit.cpp" line="11"/>
        <source>Filter</source>
        <translation>Фильтр</translation>
    </message>
    <message>
        <location filename="../FilterLineEdit.cpp" line="25"/>
        <source>These input fields allow you to perform quick filters in the currently selected table.
By default, the rows containing the input text are filtered out.
The following operators are also supported:
%	Wildcard
&gt;	Greater than
&lt;	Less than
&gt;=	Equal to or greater
&lt;=	Equal to or less
=	Equal to: exact match
&lt;&gt;	Unequal: exact inverse match
x~y	Range: values between x and y</source>
        <translation>Эти поля ввода позволяют назначить фильтры для текущей таблице.
По умолчанию строки, содержащие входной текст, отфильтровываются.
Поддерживаются также следующие операторы:
%	Символ подстановки
&gt;	Больше, чем
&lt;	Меньше, чем
&gt;=	Равно или больше
&lt;=	Равно или меньше
=	Равно: точное совпадение
&lt;&gt;	Неравномерно: точное обратное совпадение
x~y	Диапазон: значения между x и y</translation>
    </message>
    <message>
        <location filename="../FilterLineEdit.cpp" line="111"/>
        <source>Set Filter Expression</source>
        <translation>Установить Выражение Фильтра</translation>
    </message>
    <message>
        <location filename="../FilterLineEdit.cpp" line="113"/>
        <source>What&apos;s This?</source>
        <translation>Что Это?</translation>
    </message>
    <message>
        <location filename="../FilterLineEdit.cpp" line="118"/>
        <source>Is NULL</source>
        <translation>NULL</translation>
    </message>
    <message>
        <location filename="../FilterLineEdit.cpp" line="123"/>
        <source>Is not NULL</source>
        <translation>не NULL</translation>
    </message>
    <message>
        <location filename="../FilterLineEdit.cpp" line="128"/>
        <source>Is empty</source>
        <translation>пусто</translation>
    </message>
    <message>
        <location filename="../FilterLineEdit.cpp" line="133"/>
        <source>Is not empty</source>
        <translation>не пусто</translation>
    </message>
    <message>
        <location filename="../FilterLineEdit.cpp" line="138"/>
        <source>Equal to...</source>
        <translation>Равно...</translation>
    </message>
    <message>
        <location filename="../FilterLineEdit.cpp" line="142"/>
        <source>Not equal to...</source>
        <translation>Не равно...</translation>
    </message>
    <message>
        <location filename="../FilterLineEdit.cpp" line="146"/>
        <source>Greater than...</source>
        <translation>Больше чем...</translation>
    </message>
    <message>
        <location filename="../FilterLineEdit.cpp" line="150"/>
        <source>Less than...</source>
        <translation>Меньше чем...</translation>
    </message>
    <message>
        <location filename="../FilterLineEdit.cpp" line="154"/>
        <source>Greater or equal...</source>
        <translation>Больше или равно...</translation>
    </message>
    <message>
        <location filename="../FilterLineEdit.cpp" line="158"/>
        <source>Less or equal...</source>
        <translation>Меньше или равно...</translation>
    </message>
    <message>
        <location filename="../FilterLineEdit.cpp" line="162"/>
        <source>In range...</source>
        <translation>В диапазоне...</translation>
    </message>
</context>
<context>
    <name>FindReplaceDialog</name>
    <message>
        <location filename="../FindReplaceDialog.ui" line="14"/>
        <source>Find and Replace</source>
        <translation>Поиск и Замена</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="43"/>
        <source>Fi&amp;nd text:</source>
        <translation>&amp;Текст для поиска:</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="56"/>
        <source>Re&amp;place with:</source>
        <translation>Текст для &amp;замены:</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="69"/>
        <source>Match &amp;exact case</source>
        <translation>Учитывать &amp;регистр</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="79"/>
        <source>Match &amp;only whole words</source>
        <translation>Слова &amp;целиком</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="86"/>
        <source>When enabled, the search continues from the other end when it reaches one end of the page</source>
        <translation>Когда отмечено, поиск продолжается с другого конца, когда он достигает противоположного конца страницы</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="89"/>
        <source>&amp;Wrap around</source>
        <translation>&amp;Закольцевать</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="96"/>
        <source>When set, the search goes backwards from cursor position, otherwise it goes forward</source>
        <translation>Когда отмечено, поиск возвращается назад из положения курсора, в противном случае он идет вперед</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="99"/>
        <source>Search &amp;backwards</source>
        <translation>Искать в &amp;обратном порядке</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="106"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;When checked, the pattern to find is interpreted as a UNIX regular expression. See &lt;a href=&quot;https://en.wikibooks.org/wiki/Regular_Expressions&quot;&gt;Regular Expression in Wikibooks&lt;/a&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;При проверке шаблон для поиска интерпретируется как регулярное выражение UNIX. &lt;a href=&quot;https://en.wikibooks.org/wiki/Regular_Expressions&quot;&gt;Узнать больше о Регулярных выражениях на Wikibooks.org&lt;/a&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="109"/>
        <source>Use regular e&amp;xpressions</source>
        <translation>&amp;Регулярные выражения</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="129"/>
        <source>Find the next occurrence from the cursor position and in the direction set by &quot;Search backwards&quot;</source>
        <translation>Найдите следующее вхождение из позиции курсора и в направлении, заданном &quot;Искать назад&quot;</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="132"/>
        <source>&amp;Find Next</source>
        <translation>Искать &amp;дальше</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="139"/>
        <source>&amp;Replace</source>
        <translation>&amp;Замена</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="146"/>
        <source>Highlight all the occurrences of the text in the page</source>
        <translation>Выделить все вхождения текста на странице</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="149"/>
        <source>F&amp;ind All</source>
        <translation>Найти &amp;все</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="156"/>
        <source>Replace all the occurrences of the text in the page</source>
        <translation>Заменить все вхождения текста на странице</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.ui" line="159"/>
        <source>Replace &amp;All</source>
        <translation>За&amp;менить все</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.cpp" line="49"/>
        <source>The searched text was not found</source>
        <translation>Искомый текст не найден</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.cpp" line="95"/>
        <location filename="../FindReplaceDialog.cpp" line="129"/>
        <source>The searched text was not found.</source>
        <translation>Искомый текст не найден.</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.cpp" line="98"/>
        <source>The searched text was found one time.</source>
        <translation>Искомый текст найден один раз.</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.cpp" line="101"/>
        <source>The searched text was found %1 times.</source>
        <translation>Искомый текст найден %1 раз.</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.cpp" line="132"/>
        <source>The searched text was replaced one time.</source>
        <translation>Искомый текст заменен один раз.</translation>
    </message>
    <message>
        <location filename="../FindReplaceDialog.cpp" line="135"/>
        <source>The searched text was replaced %1 times.</source>
        <translation>Искомый текст заменен %1 раз.</translation>
    </message>
</context>
<context>
    <name>ForeignKeyEditor</name>
    <message>
        <location filename="../ForeignKeyEditorDelegate.cpp" line="19"/>
        <source>&amp;Reset</source>
        <translation>&amp;Сброс</translation>
    </message>
    <message>
        <location filename="../ForeignKeyEditorDelegate.cpp" line="22"/>
        <source>Foreign key clauses (ON UPDATE, ON DELETE etc.)</source>
        <translation>Условия (ON UPDATE, ON DELETE и т.д.)</translation>
    </message>
</context>
<context>
    <name>ImportCsvDialog</name>
    <message>
        <location filename="../ImportCsvDialog.ui" line="14"/>
        <source>Import CSV file</source>
        <translation>Импортировать файл в формате CSV</translation>
    </message>
    <message>
        <source>&amp;Table name</source>
        <translation type="vanished">&amp;Имя таблицы</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="25"/>
        <source>Table na&amp;me</source>
        <translation>&amp;Имя таблицы</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="38"/>
        <source>&amp;Column names in first line</source>
        <translation>И&amp;мена столбцов в первой строке</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="55"/>
        <source>Field &amp;separator</source>
        <translation>&amp;Разделитель полей</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="68"/>
        <source>,</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="73"/>
        <source>;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="78"/>
        <location filename="../ImportCsvDialog.cpp" line="749"/>
        <source>Tab</source>
        <translation>Табуляция</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="83"/>
        <source>|</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="88"/>
        <location filename="../ImportCsvDialog.ui" line="146"/>
        <location filename="../ImportCsvDialog.ui" line="204"/>
        <source>Other</source>
        <translation>Другой</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="118"/>
        <source>&amp;Quote character</source>
        <translation>&amp;Символ кавычки</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="131"/>
        <source>&quot;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="136"/>
        <source>&apos;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="176"/>
        <source>&amp;Encoding</source>
        <translation>&amp;Кодировка</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="189"/>
        <source>UTF-8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="194"/>
        <source>UTF-16</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="199"/>
        <source>ISO-8859-1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="230"/>
        <source>Trim fields?</source>
        <translation>Обрезать поля?</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="250"/>
        <source>Separate tables</source>
        <translation>Отдельные таблицы</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="267"/>
        <source>Advanced</source>
        <translation>Дополнительно</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="281"/>
        <source>When importing an empty value from the CSV file into an existing table with a default value for this column, that default value is inserted. Activate this option to insert an empty value instead.</source>
        <translation>При импорте пустого значения из файла CSV в существующую таблицу для столбца с указанным значением по умолчанию оно будет вставлено. Активируйте эту опцию, чтобы вместо этого вставить пустое значение.</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="288"/>
        <source>Ignore default &amp;values</source>
        <translation>Игнорировать значение &amp;по-умолчанию</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="298"/>
        <source>Activate this option to stop the import when trying to import an empty value into a NOT NULL column without a default value.</source>
        <translation>Активируйте эту опцию чтобы прекратить импорт при попытке импорта пустого значения в NOT NULL колонку без значения по-умолчанию.</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="305"/>
        <source>Fail on missing values </source>
        <translation>Ошибка при отсутствии значений </translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="315"/>
        <source>Disable data type detection</source>
        <translation>Отключить определение типа данных</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="322"/>
        <source>Disable the automatic data type detection when creating a new table.</source>
        <translation>Отключить автоматическое определение типа при создании новой таблицы.</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="370"/>
        <location filename="../ImportCsvDialog.cpp" line="332"/>
        <source>Deselect All</source>
        <translation>Отменить Выбор</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.ui" line="386"/>
        <source>Match Similar</source>
        <translation>Найти Совпадения</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.cpp" line="332"/>
        <source>Select All</source>
        <translation>Выбрать Все</translation>
    </message>
    <message>
        <source>Inserting data...</source>
        <translation type="vanished">Вставка данных...</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">Отменить</translation>
    </message>
    <message>
        <source>There is already a table of that name and an import into an existing table is only possible if the number of columns match.</source>
        <translation type="vanished">Уже существует таблица с таким же именем, и импорт в существующую таблицу возможен, только если число столбцов совпадает.</translation>
    </message>
    <message>
        <source>There is already a table of that name. Do you want to import the data into it?</source>
        <translation type="vanished">Уже существует таблица с таким именем. Импортировать данные в неё?</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.cpp" line="212"/>
        <source>Import completed</source>
        <translation>Импорт завершён</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.cpp" line="502"/>
        <source>There is already a table named &apos;%1&apos; and an import into an existing table is only possible if the number of columns match.</source>
        <translation>Уже существует таблица с именем &apos;%1&apos; и импорт в существующую таблицу возможен, только если число столбцов совпадает.</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.cpp" line="509"/>
        <source>There is already a table named &apos;%1&apos;. Do you want to import the data into it?</source>
        <translation>Уже существует таблица с именем &apos;%1&apos;. Вы хотите импортировать данные в нее?</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.cpp" line="536"/>
        <source>Creating restore point failed: %1</source>
        <translation>Ошибка сознания точки восстановления: %1</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.cpp" line="549"/>
        <source>Creating the table failed: %1</source>
        <translation>Ошибка создания таблицы: %1</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.cpp" line="610"/>
        <source>importing CSV</source>
        <translation>импортирование CSV</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.cpp" line="691"/>
        <source>Importing the file &apos;%1&apos; took %2ms. Of this %3ms were spent in the row function.</source>
        <translation>Импорт файла &apos;%1&apos; занял %2мс. Из них %3мс было потрачено в функции строки.</translation>
    </message>
    <message>
        <source>Missing field for record %1</source>
        <translation type="vanished">Пропущен столбец для записи %1</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.cpp" line="681"/>
        <source>Inserting row failed: %1</source>
        <translation>Ошибка вставки строки: %1</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../MainWindow.ui" line="14"/>
        <source>DB Browser for SQLite</source>
        <translation>Обозреватель для SQLite</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="935"/>
        <source>toolBar1</source>
        <translation>панельИнструментов1</translation>
    </message>
    <message>
        <source>Table:</source>
        <translation type="vanished">Таблица:</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="130"/>
        <source>Select a table to browse data</source>
        <translation>Выберите таблицу для просмотра данных</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="133"/>
        <source>Use this list to select a table to be displayed in the database view</source>
        <translation>Используйте этот список, чтобы выбрать таблицу, которая должна быть отображена в представлении базы данных</translation>
    </message>
    <message>
        <source>Refresh the data in the selected table.</source>
        <translation type="vanished">Обновить данные в выбранной таблице.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="149"/>
        <source>This button refreshes the data in the currently selected table.</source>
        <translation>Эта кнопка отновляет данные выбранной в данный момент таблицы.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="166"/>
        <source>This button clears all the filters set in the header input fields for the currently browsed table.</source>
        <translation>Эта кнопка очищает все фильтры, установленные в полях ввода заголовка для текущей просматриваемой таблицы.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="180"/>
        <source>Save the table as currently displayed</source>
        <translation>Сохранить таблицу так как сейчас отображается</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="183"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This popup menu provides the following options applying to the currently browsed and filtered table:&lt;/p&gt;&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Export to CSV: this option exports the data of the browsed table as currently displayed (after filters, display formats and order column) to a CSV file.&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Save as view: this option saves the current setting of the browsed table (filters, display formats and order column) as an SQL view that you can later browse or use in SQL statements.&lt;/li&gt;&lt;/ul&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Это всплывающее меню предоставляет следующие параметры, применяемые к текущей просматриваемой и отфильтрованной таблице:&lt;/p&gt;&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Экспортировать ввиде CSV: данные просматриваемой таблицы сохраняется так как отображается (после применения фильтров, форматов отображения и порядка колонок) в CSV файл.&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Сохранить как вид: эта опция сохраняет настройки текущей отображаемой таблицы (фильтры, форматы отображения и порядок колонок) как SQL вид, который вы позже можете просматривать или использовать в SQL выражениях.&lt;/li&gt;&lt;/ul&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="186"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="197"/>
        <source>Print currently browsed table data</source>
        <translation>Печатать отображаемую таблицу</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="200"/>
        <source>Print currently browsed table data. Print selection if more than one cell is selected.</source>
        <translation>Распечатывайте текущие данные таблицы. Выбор печати, если выбрано несколько ячеек.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="227"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This button creates a new record in the database. Hold the mouse button to open a pop-up menu of different options:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New Record&lt;/span&gt;: insert a new record with default values in the database.&lt;/li&gt;&lt;li&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Values...&lt;/span&gt;: open a dialog for entering values before they are inserted in the database. This allows to enter values acomplishing the different constraints. This dialog is also open if the &lt;span style=&quot; font-weight:600;&quot;&gt;New Record&lt;/span&gt; option fails due to these constraints.&lt;/li&gt;&lt;/ul&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Эта кнопка создает новую запись в базе данных. Удерживайте кнопку мыши, чтобы открыть всплывающее меню различных параметров:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Новая Запись&lt;/span&gt;: вставляет новую запись со значениями по умолчанию.&lt;/li&gt;&lt;li&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Вставить Значения...&lt;/span&gt;: открывает диалог для ввода значений перед тем, как они будут вставленны в БД. Это позволяет вводить значения, назначая различные ограничения. Этот диалог также открывается, если &lt;span style=&quot; font-weight:600;&quot;&gt;Новая Запись&lt;/span&gt; опция не срабатывает из-за этих ограничений.&lt;/li&gt;&lt;/ul&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="240"/>
        <source>This button deletes the record or records currently selected in the table</source>
        <translation>Эта кнопка удаляет запись или записи, выбранные в настоящее время в таблице</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="255"/>
        <source>This is the database table view. You can do the following actions:
 - Start writing for editing inline the value.
 - Double-click any record to edit its contents in the cell editor window.
 - Alt+Del for deleting the cell content to NULL.
 - Ctrl+&quot; for duplicating the current record.
 - Ctrl+&apos; for copying the value from the cell above.
 - Standard selection and copy/paste operations.</source>
        <translation>Это представление таблицы БД. Вы можете выполнить следующие действия:
  - Начните писать для редактирования, введя значение.
  - Дважды щелкните любую запись, чтобы отредактировать ее содержимое в окне редактора ячеек.
  - Alt + Del для обнуления содержимого ячейки в NULL.
  - Ctrl + &quot; для дублирования текущей записи.
  - Ctrl + &apos; для копирования значения из ячейки выше.
  - Стандартные операции выбора и копирования/вставки.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="308"/>
        <source>Scroll one page upwards</source>
        <translation>Страница вверх</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="311"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Clicking this button navigates one page of records upwards in the table view above.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Нажатие этой кнопки перемещает одну страницу записей вверх в виде таблицы выше.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="335"/>
        <source>Scroll one page downwards</source>
        <translation>Страница вниз</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="338"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Clicking this button navigates one page of records downwards in the table view above.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Нажатие этой кнопки перемещает одну страницу записей вниз в виде таблицы выше.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="493"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://www.sqlite.org/pragma.html#pragma_case_sensitive_like&quot;&gt;Case Sensitive Like&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="506"/>
        <source>Warning: this pragma is not readable and this value has been inferred. Writing the pragma might overwrite a redefined LIKE provided by an SQLite extension.</source>
        <translation>Предупреждение: эта прагма не читается, и это значение было выведено. Применение прагмы может перезаписать переопределенный LIKE, предоставляемый расширением SQLite.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1054"/>
        <source>&amp;Tools</source>
        <translation>&amp;Инструменты</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1173"/>
        <source>This button clears the contents of the SQL logs</source>
        <translation>Эта кнопка очищает содержимое журналов SQL</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1185"/>
        <source>This panel lets you examine a log of all SQL commands issued by the application or by yourself</source>
        <translation>Эта панель позволяет вам просматривать журнал всех SQL-команд, выданных приложением или вами</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1246"/>
        <source>This is the structure of the opened database.
You can drag multiple object names from the Name column and drop them into the SQL editor and you can adjust the properties of the dropped names using the context menu. This would help you in composing SQL statements.
You can drag SQL statements from the Schema column and drop them into the SQL editor or into other applications.
</source>
        <translation>Это структура открытой БД.
Вы можете перетащить несколько имен объектов из столбца &quot;Имя&quot; и отбросить их в редактор SQL, и вы можете настроить свойства сброшенных имен с помощью контекстного меню. Это поможет вам при составлении SQL-инструкций.
Вы можете перетаскивать операторы SQL из столбца &quot;Схема&quot; и переносить их в редактор SQL или в другие приложения.
</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1288"/>
        <location filename="../MainWindow.ui" line="2153"/>
        <source>Project Toolbar</source>
        <translation>Панель Инструментов Проекта</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1307"/>
        <source>Extra DB toolbar</source>
        <translation>Дополнительная Панель Инструментов БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1310"/>
        <location filename="../MainWindow.ui" line="1384"/>
        <location filename="../MainWindow.ui" line="1387"/>
        <source>Close the current database file</source>
        <translation>Закрыть файл текущей БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1668"/>
        <source>&amp;About</source>
        <translation>О &amp;программе</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1688"/>
        <source>This button opens a new tab for the SQL editor</source>
        <translation>Эта кнопка открывает новую вкладку для редактора SQL</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1703"/>
        <source>Execute all/selected SQL</source>
        <translation>Выполнить все/выбранный SQL</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1706"/>
        <source>This button executes the currently selected SQL statements. If no text is selected, all SQL statements are executed.</source>
        <translation>Эта кнопка выполняет текущие выбранные операторы SQL. Если в текстовом редакторе ничего не выбрано , все инструкции SQL выполняются.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1718"/>
        <source>This button opens a file containing SQL statements and loads it in a new editor tab</source>
        <translation>Эта кнопка открывает файл, содержащий инструкции SQL, и загружает его в новой вкладке редактора</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1739"/>
        <source>&amp;Load Extension...</source>
        <translation>&amp;Загрузить расширение...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1757"/>
        <source>This button executes the SQL statement present in the current editor line</source>
        <translation>Эта кнопка выполняет оператор SQL, присутствующий в текущей строке редактора</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1780"/>
        <source>&amp;Wiki</source>
        <translation>&amp;Вики</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1792"/>
        <source>Bug &amp;Report...</source>
        <translation>Баг &amp;репорт...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1804"/>
        <source>Feature Re&amp;quest...</source>
        <translation>Запросить &amp;функцию...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1816"/>
        <source>Web&amp;site</source>
        <translation>&amp;Веб-сайт</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1828"/>
        <source>&amp;Donate on Patreon...</source>
        <translation>Сделать &amp;пожертвование в Patreon...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1840"/>
        <source>Sa&amp;ve Project...</source>
        <translation>&amp;Сохранить проект...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1849"/>
        <source>This button lets you save all the settings associated to the open DB to a DB4S project file</source>
        <translation>Эта кнопка позволяет сохранить все настройки, связанные с открытой БД, в файл проекта DB4S</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1861"/>
        <source>Open &amp;Project...</source>
        <translation>Открыть &amp;проект...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1870"/>
        <source>This button lets you open a DB4S project file</source>
        <translation>Эта кнопка позволяет открыть файл проекта DB4S</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1885"/>
        <source>&amp;Attach Database...</source>
        <translation>&amp;Прикрепить БД...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1888"/>
        <location filename="../MainWindow.ui" line="1891"/>
        <source>Add another database file to the current database connection</source>
        <translation>Добавить другой файл БД в текущее соединение</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1894"/>
        <source>This button lets you add another database file to the current database connection</source>
        <translation>Эта кнопка позволяет добавить другой файл БД в текущее соединение с БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1906"/>
        <source>&amp;Set Encryption...</source>
        <translation>Назначитть &amp;шифрование...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1936"/>
        <source>This button saves the content of the current SQL editor tab to a file</source>
        <translation>Эта кнопка сохраняет содержимое текущей вкладки редактора SQL в файл</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2001"/>
        <source>SQLCipher &amp;FAQ</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2009"/>
        <source>Table(&amp;s) to JSON...</source>
        <translation>Таблицы в файл &amp;JSON...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2020"/>
        <source>Refresh</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2023"/>
        <source>F5</source>
        <translation>F5</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2032"/>
        <source>Open Data&amp;base Read Only...</source>
        <translation>Открыть БД &amp;только для чтения...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2064"/>
        <source>Save results</source>
        <translation>Сохранить результаты</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2067"/>
        <source>Save the results view</source>
        <translation>Сохранить результаты</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2070"/>
        <source>This button lets you save the results of the last executed query</source>
        <translation>Эта кнопка позволяет сохранить результаты последнего выполненного запроса</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2082"/>
        <source>Find text in SQL editor</source>
        <translation>Найти текст в редакторе SQL</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2085"/>
        <source>Find text in SQL editor</source>
        <translation>Найти текст в редакторе SQL</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2088"/>
        <source>This button opens the search bar of the editor</source>
        <translation>Эта кнопка открывает панель поиска редактора</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2091"/>
        <source>Ctrl+F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2103"/>
        <source>Find or replace text in SQL editor</source>
        <translation>Найти или заменить текст в редакторе SQL</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2106"/>
        <source>Find or replace text in SQL editor</source>
        <translation>Найти или заменить текст в редакторе SQL</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2109"/>
        <source>This button opens the find/replace dialog for the current editor tab</source>
        <translation>Эта кнопка открывает диалог поиска/замены для текущей вкладки редактора</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2114"/>
        <location filename="../MainWindow.ui" line="2176"/>
        <source>Export to &amp;CSV</source>
        <translation>Экспортировать в &amp;CSV</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2119"/>
        <location filename="../MainWindow.ui" line="2190"/>
        <source>Save as &amp;view</source>
        <translation>Сохранить как &amp;представление</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2122"/>
        <source>Save as view</source>
        <translation>Сохранить как представление</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2127"/>
        <source>Hide column(s)</source>
        <translation>Скрыть колонки</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2130"/>
        <source>Hide selected column(s)</source>
        <translation>Скрыть выбранные колонки</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2135"/>
        <source>Show all columns</source>
        <translation>Показать все колонки</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2138"/>
        <source>Show all columns that were hidden</source>
        <translation>Показать все колонки, которые были скрыты</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2156"/>
        <source>Shows or hides the Project toolbar.</source>
        <translation>Показывает или скрывает панель инструментов Проекта.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2171"/>
        <source>Extra DB Toolbar</source>
        <translation>Дополнительная Панель Инструментов БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2179"/>
        <location filename="../MainWindow.ui" line="2182"/>
        <source>Export the filtered data to CSV</source>
        <translation>Экспортировать отфильтрованные данные в CSV</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2185"/>
        <source>This button exports the data of the browsed table as currently displayed (after filters, display formats and order column) as a CSV file.</source>
        <translation>Эта кнопка экспортирует данные просматриваемой таблицы так как отображается (после обработки фильтрами, форматами отображения и т.д.) в виде файла CSV.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2193"/>
        <location filename="../MainWindow.ui" line="2196"/>
        <source>Save the current filter, sort column and display formats as a view</source>
        <translation>Сохранить текущие фильтры, столбецы сортировки и форматы отображания в виде представления</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2199"/>
        <source>This button saves the current setting of the browsed table (filters, display formats and order column) as an SQL view that you can later browse or use in SQL statements.</source>
        <translation>Эта кнопка сохраняет текущие настройки просматриваемой таблицы (фильтры, форматы отображения и столбец сортировки) в виде представления SQL, которое вы можете впоследствии просмотреть или использовать в операторах SQL.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2228"/>
        <source>Insert Values...</source>
        <translation>Вставить Значения...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2231"/>
        <location filename="../MainWindow.ui" line="2234"/>
        <source>Open a dialog for inserting values in a new record</source>
        <translation>Открывает диалоговое окно для вставки значений в новую запись</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2242"/>
        <location filename="../MainWindow.ui" line="2245"/>
        <source>Insert new record using default values in browsed table</source>
        <translation>Вставляет новую запись, используя значения по умолчанию в просматриваемой таблице</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2250"/>
        <source>New In-&amp;Memory Database</source>
        <translation>Новая БД в &amp;Памяти</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2258"/>
        <source>Drag &amp;&amp; Drop Qualified Names</source>
        <translation>Квалифицированные имена при перетакскивании</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2261"/>
        <location filename="../MainWindow.ui" line="2264"/>
        <source>Use qualified names (e.g. &quot;Table&quot;.&quot;Field&quot;) when dragging the objects and dropping them into the editor </source>
        <translation>Квалифицированные имена (например, &quot;Table&quot;.&quot;Field&quot;) при перетаскивании объектов в редактор </translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2272"/>
        <source>Drag &amp;&amp; Drop Enquoted Names</source>
        <translation>Экранированные имена при перетаскивании</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2275"/>
        <location filename="../MainWindow.ui" line="2278"/>
        <source>Use escaped identifiers (e.g. &quot;Table1&quot;) when dragging the objects and dropping them into the editor </source>
        <translation>Экранировать имена идентификаторов (например, &quot;Table1&quot;), когда перетаскиваются объекты в редактор </translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2283"/>
        <source>&amp;Integrity Check</source>
        <translation>Проверка &amp;Целостности</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2286"/>
        <source>Runs the integrity_check pragma over the opened database and returns the results in the Execute SQL tab. This pragma does an integrity check of the entire database.</source>
        <translation>Выполняет прагму integrity_check для открытой БД и возвращает результаты во вкладке &quot;SQL&quot;. Эта прагма выполняет проверку целостности всей базы данных.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2291"/>
        <source>&amp;Foreign-Key Check</source>
        <translation>Проверка &amp;Внешних ключей</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2294"/>
        <source>Runs the foreign_key_check pragma over the opened database and returns the results in the Execute SQL tab</source>
        <translation>Запускает прагму foreign_key_check для открытой БД и возвращает результаты во вкладке &quot;SQL&quot;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2299"/>
        <source>&amp;Quick Integrity Check</source>
        <translation>&amp;Быстрая Проверка Целостности</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2302"/>
        <source>Run a quick integrity check over the open DB</source>
        <translation>Запуск быстрой проверки целостности для открытый БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2305"/>
        <source>Runs the quick_check pragma over the opened database and returns the results in the Execute SQL tab. This command does most of the checking of PRAGMA integrity_check but runs much faster.</source>
        <translation>Запускает прагму quick_check для открытой БД и возвращает результаты во вкладке &quot;SQL&quot;. Эта команда выполняет большую часть проверки PRAGMA integrity_check, но работает намного быстрее.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2310"/>
        <source>&amp;Optimize</source>
        <translation>&amp;Оптимизация</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2313"/>
        <source>Attempt to optimize the database</source>
        <translation>Попытка оптимизации БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2316"/>
        <source>Runs the optimize pragma over the opened database. This pragma might perform optimizations that will improve the performance of future queries.</source>
        <translation>Выполняет прагму optimize для открытой БД. Эта прагма может выполнять оптимизацию, которая улучшит производительность будущих запросов.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2325"/>
        <location filename="../MainWindow.ui" line="2349"/>
        <source>Print</source>
        <translation>Печать</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2328"/>
        <source>Print text from current SQL editor tab</source>
        <translation>Печать текста изтекущей вкладки редактора SQL</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2334"/>
        <source>Open a dialog for printing the text in the current SQL editor tab</source>
        <translation>Открывает диалоговое окно для печати текста из текущей вкладки редактора SQL</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2352"/>
        <source>Print the structure of the opened database</source>
        <translation>Печать структуры открытой БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2358"/>
        <source>Open a dialog for printing the structure of the opened database</source>
        <translation>Открывает диалоговое окно для печати структуры текущей БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="224"/>
        <source>Insert a new record in the current table</source>
        <translation>Добавить новую запись в текущую таблицу</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="102"/>
        <source>&amp;Table:</source>
        <translation>&amp;Таблица:</translation>
    </message>
    <message>
        <source>This button creates a new, empty record in the database</source>
        <translation type="vanished">Эта кнопка создаёт новую, пустую запись в таблице</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="230"/>
        <location filename="../MainWindow.ui" line="2239"/>
        <source>New Record</source>
        <translation>Добавить запись</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="237"/>
        <source>Delete the current record</source>
        <translation>Удалить текущую запись</translation>
    </message>
    <message>
        <source>This button deletes the record currently selected in the database</source>
        <translation type="vanished">Эта кнопка удаляет выбранную запись</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="243"/>
        <location filename="../MainWindow.cpp" line="3428"/>
        <source>Delete Record</source>
        <translation>Удалить запись</translation>
    </message>
    <message>
        <source>This is the database view. You can double-click any record to edit its contents in the cell editor window.</source>
        <translation type="vanished">Это представление базы данных. Сделайте двойной щелчок по любой записи, чтобы отредактировать её содержимое.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="288"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Scroll to the beginning&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Прокрутить к началу&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="291"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Clicking this button navigates to the beginning in the table view above.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Нажатие этой кнопки переводит к началу в таблице выше.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="294"/>
        <source>|&lt;</source>
        <translation></translation>
    </message>
    <message>
        <source>Scroll 100 records upwards</source>
        <translation type="vanished">Прокрутить на 100 записей вверх</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Clicking this button navigates 100 records upwards in the table view above.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Нажатие этой кнопки к перемещению на 100 записей вверх в табличном представлении выше&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="314"/>
        <source>&lt;</source>
        <translation>&lt;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="325"/>
        <source>0 - 0 of 0</source>
        <translation>0 - 0 из 0</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Scroll 100 records downwards&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Прокрутить на 100 записей вниз&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Clicking this button navigates 100 records downwards in the table view above.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Нажатие этой кнопки к перемещению на 100 записей вниз в табличном представлении выше&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="341"/>
        <source>&gt;</source>
        <translation>&gt;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="355"/>
        <source>Scroll to the end</source>
        <translation>Прокрутить к концу</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="358"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;Clicking this button navigates up to the end in the table view above.&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;Нажатие этой кнопки перемещает в конец таблицы выше.&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="361"/>
        <source>&gt;|</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="385"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Click here to jump to the specified record&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Нажмите здесь, чтобы перейти к указанной записи&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="388"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This button is used to navigate to the record number specified in the Go to area.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Эта кнопка используется, чтобы переместиться к записи, номер которой указан в области Перейти к&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="391"/>
        <source>Go to:</source>
        <translation>Перейти к:</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="398"/>
        <source>Enter record number to browse</source>
        <translation>Введите номер записи для просмотра</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="401"/>
        <source>Type a record number in this area and click the Go to: button to display the record in the database view</source>
        <translation>Напечатайте номер записи в этой области и нажмите кнопку Перейти к:, чтобы отобразить запись в представлении базы данных</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="404"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_auto_vacuum&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Auto Vacuum&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_auto_vacuum&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Auto Vacuum&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="vanished">Нет</translation>
    </message>
    <message>
        <source>Full</source>
        <translatorcomment>Полный, целый</translatorcomment>
        <translation type="vanished">Full</translation>
    </message>
    <message>
        <source>Incremental</source>
        <translation type="vanished">Incremental</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_automatic_index&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Automatic Index&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_automatic_index&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Automatic Index&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_checkpoint_fullfsync&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Checkpoint Full FSYNC&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_checkpoint_fullfsync&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Checkpoint Full FSYNC&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_foreign_keys&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Foreign Keys&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_foreign_keys&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Foreign Keys&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_fullfsync&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Full FSYNC&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_fullfsync&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Full FSYNC&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_ignore_check_constraints&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Ignore Check Constraints&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_ignore_check_constraints&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Ignore Check Constraints&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_journal_mode&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Journal Mode&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_journal_mode&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Journal Mode&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Delete</translation>
    </message>
    <message>
        <source>Truncate</source>
        <translation type="vanished">Truncate</translation>
    </message>
    <message>
        <source>Persist</source>
        <translation type="vanished">Persist</translation>
    </message>
    <message>
        <source>Memory</source>
        <translation type="vanished">Memory</translation>
    </message>
    <message>
        <source>WAL</source>
        <translation type="vanished">WAL</translation>
    </message>
    <message>
        <source>Off</source>
        <translation type="vanished">Off</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_journal_size_limit&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Journal Size Limit&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_journal_size_limit&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Journal Size Limit&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_locking_mode&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Locking Mode&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_locking_mode&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Locking Mode&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="vanished">Normal</translation>
    </message>
    <message>
        <source>Exclusive</source>
        <translation type="vanished">Exclusive</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_max_page_count&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Max Page Count&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_max_page_count&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Max Page Count&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_page_size&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Page Size&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_page_size&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Page Size&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_recursive_triggers&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Recursive Triggers&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_recursive_triggers&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Recursive Triggers&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_secure_delete&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Secure Delete&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_secure_delete&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Secure Delete&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_synchronous&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Synchronous&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_synchronous&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Synchronous&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_temp_store&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Temp Store&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_temp_store&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Temp Store&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="vanished">Default</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="vanished">File</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_user_version&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;User Version&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_user_version&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;User Version&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_wal_autocheckpoint&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;WAL Auto Checkpoint&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://www.sqlite.org/pragma.html#pragma_wal_autocheckpoint&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;WAL Auto Checkpoint&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="981"/>
        <source>&amp;File</source>
        <translation>&amp;Файл</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="985"/>
        <source>&amp;Import</source>
        <translation>&amp;Импорт</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="992"/>
        <source>&amp;Export</source>
        <translation>&amp;Экспорт</translation>
    </message>
    <message>
        <source>Remote</source>
        <translation type="vanished">Удаленный сервер</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1018"/>
        <source>&amp;Edit</source>
        <translation>&amp;Редактирование</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1030"/>
        <source>&amp;View</source>
        <translation>&amp;Вид</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1038"/>
        <source>&amp;Help</source>
        <translation>&amp;Справка</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1075"/>
        <source>DB Toolbar</source>
        <translation>Панель инструментов БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1094"/>
        <source>Edit Database &amp;Cell</source>
        <translation>Редактирование &amp;ячейки БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1233"/>
        <source>DB Sche&amp;ma</source>
        <translation>Схе&amp;ма БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1279"/>
        <source>&amp;Remote</source>
        <translation>&amp;Удаленный сервер</translation>
    </message>
    <message>
        <source>&amp;Load extension</source>
        <translation type="vanished">Загрузить &amp;расширение</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1754"/>
        <source>Execute current line</source>
        <translation>Выполнить текущую строку</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1760"/>
        <source>Shift+F5</source>
        <translation>Shift+F5</translation>
    </message>
    <message>
        <source>Sa&amp;ve Project</source>
        <translation type="vanished">&amp;Сохранить проект</translation>
    </message>
    <message>
        <source>Open &amp;Project</source>
        <translation type="vanished">Открыть &amp;проект</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1962"/>
        <source>Edit display format</source>
        <translation>Формат отображения</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1965"/>
        <source>Edit the display format of the data in this column</source>
        <translation>Редактирование формата отображения для данных из этой колонки</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1973"/>
        <source>Show rowid column</source>
        <translation>Отображать колонку rowid</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1976"/>
        <source>Toggle the visibility of the rowid column</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1981"/>
        <location filename="../MainWindow.cpp" line="3128"/>
        <source>Set encoding</source>
        <translation>Кодировка</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1984"/>
        <source>Change the encoding of the text in the table cells</source>
        <translation>Изменение кодировки текста в данной таблице</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1989"/>
        <source>Set encoding for all tables</source>
        <translation>Установить кодировку для всех таблиц</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1992"/>
        <source>Change the default encoding assumed for all tables in the database</source>
        <translation>Изменить кодировку по умолчанию для всех таблиц в базе данных</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2035"/>
        <source>Open an existing database file in read only mode</source>
        <translation>Открыть существующий файл базы данных в режиме только для чтения</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2052"/>
        <source>Unlock view editing</source>
        <translation>Разблокировать возможность редактирования</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2055"/>
        <source>This unlocks the current view for editing. However, you will need appropriate triggers for editing.</source>
        <translation>Разблокировать текущий вид для редактирования. Однако для редактирования вам понадобятся соответствующие триггеры.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3022"/>
        <source>Duplicate record</source>
        <translation>Дубликат записи</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2004"/>
        <source>Opens the SQLCipher FAQ in a browser window</source>
        <translation>Открыть SQLCiphier FAQ в браузере</translation>
    </message>
    <message>
        <source>Table(s) to JSON...</source>
        <translation type="vanished">Таблицы в файл JSON...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2012"/>
        <source>Export one or more table(s) to a JSON file</source>
        <translation>Экспортировать таблицы в JSON файл</translation>
    </message>
    <message>
        <source>Open from Remote</source>
        <translation type="vanished">Загрузить из облака</translation>
    </message>
    <message>
        <source>Save to Remote</source>
        <translation type="vanished">Сохранить в облако</translation>
    </message>
    <message>
        <source>&amp;Attach Database</source>
        <translation type="vanished">&amp;Прикрепить базу данных</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1918"/>
        <location filename="../MainWindow.ui" line="1921"/>
        <source>Save SQL file as</source>
        <translation>Сохранить файл SQL как</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1945"/>
        <source>&amp;Browse Table</source>
        <translation>Пр&amp;осмотр данных</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="163"/>
        <source>Clear all filters</source>
        <translation>Очистить все фильтры</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1141"/>
        <source>User</source>
        <translation>Пользователем</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1146"/>
        <source>Application</source>
        <translation>Приложением</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1176"/>
        <source>&amp;Clear</source>
        <translation>О&amp;чистить</translation>
    </message>
    <message>
        <source>Columns</source>
        <translation type="vanished">Столбцы</translation>
    </message>
    <message>
        <source>X</source>
        <translation type="vanished">X</translation>
    </message>
    <message>
        <source>Y</source>
        <translation type="vanished">Y</translation>
    </message>
    <message>
        <source>_</source>
        <translation type="vanished">_</translation>
    </message>
    <message>
        <source>Line type:</source>
        <translation type="vanished">Линия:</translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="vanished">Обычная</translation>
    </message>
    <message>
        <source>StepLeft</source>
        <translation type="vanished">Ступенчатая, слева</translation>
    </message>
    <message>
        <source>StepRight</source>
        <translation type="vanished">Ступенчатая, справа</translation>
    </message>
    <message>
        <source>StepCenter</source>
        <translation type="vanished">Ступенчатая, по центру</translation>
    </message>
    <message>
        <source>Impulse</source>
        <translation type="vanished">Импульс</translation>
    </message>
    <message>
        <source>Point shape:</source>
        <translation type="vanished">Отрисовка точек:</translation>
    </message>
    <message>
        <source>Cross</source>
        <translation type="vanished">Крест</translation>
    </message>
    <message>
        <source>Plus</source>
        <translation type="vanished">Плюс</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation type="vanished">Круг</translation>
    </message>
    <message>
        <source>Disc</source>
        <translation type="vanished">Диск</translation>
    </message>
    <message>
        <source>Square</source>
        <translation type="vanished">Квадрат</translation>
    </message>
    <message>
        <source>Diamond</source>
        <translation type="vanished">Ромб</translation>
    </message>
    <message>
        <source>Star</source>
        <translation type="vanished">Звезда</translation>
    </message>
    <message>
        <source>Triangle</source>
        <translation type="vanished">Треугольник</translation>
    </message>
    <message>
        <source>TriangleInverted</source>
        <translation type="vanished">Треугольник перевернутый</translation>
    </message>
    <message>
        <source>CrossSquare</source>
        <translation type="vanished">Крест в квадрате</translation>
    </message>
    <message>
        <source>PlusSquare</source>
        <translation type="vanished">Плюс в квадрате</translation>
    </message>
    <message>
        <source>CrossCircle</source>
        <translation type="vanished">Крест в круге</translation>
    </message>
    <message>
        <source>PlusCircle</source>
        <translation type="vanished">Плюс в круге</translation>
    </message>
    <message>
        <source>Peace</source>
        <translation type="vanished">Мир</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Save current plot...&lt;/p&gt;&lt;p&gt;File format chosen by extension (png, jpg, pdf, bmp)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Сохранить текущий график...&lt;/p&gt;&lt;p&gt;Формат файла выбирается расширением (png, jpg, pdf, bmp)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Save current plot...</source>
        <translation type="vanished">Сохранить текущий график...</translation>
    </message>
    <message>
        <source>Load all data. This has only an effect if not all data has been fetched from the table yet due to the partial fetch mechanism.</source>
        <translation type="vanished">Загружать все данные. Имеет эффект лишь если не все данные подгружены.</translation>
    </message>
    <message>
        <source>DB Schema</source>
        <translation type="obsolete">Схема БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1330"/>
        <source>&amp;New Database...</source>
        <translation>&amp;Новая база данных...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1333"/>
        <location filename="../MainWindow.ui" line="1336"/>
        <source>Create a new database file</source>
        <translation>Создать новый файл базы данных</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1339"/>
        <source>This option is used to create a new database file.</source>
        <translation>Эта опция используется, чтобы создать новый файл базы данных.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1342"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1354"/>
        <location filename="../MainWindow.ui" line="2208"/>
        <source>&amp;Open Database...</source>
        <translation>&amp;Открыть базу данных...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1357"/>
        <location filename="../MainWindow.ui" line="1360"/>
        <location filename="../MainWindow.ui" line="2038"/>
        <location filename="../MainWindow.ui" line="2211"/>
        <location filename="../MainWindow.ui" line="2214"/>
        <source>Open an existing database file</source>
        <translation>Открыть существующий файл базы данных</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1363"/>
        <location filename="../MainWindow.ui" line="2041"/>
        <location filename="../MainWindow.ui" line="2217"/>
        <source>This option is used to open an existing database file.</source>
        <translation>Эта опция используется, чтобы открыть существующий файл базы данных.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1366"/>
        <location filename="../MainWindow.ui" line="2220"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1381"/>
        <source>&amp;Close Database</source>
        <translation>&amp;Закрыть базу данных</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1390"/>
        <source>This button closes the connection to the currently open database file</source>
        <translation>Эта кнопка закрывает соединение с текущим файлом БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1393"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1411"/>
        <location filename="../MainWindow.ui" line="1414"/>
        <source>Revert database to last saved state</source>
        <translation>Вернуть базу данных в последнее сохранённое состояние</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1417"/>
        <source>This option is used to revert the current database file to its last saved state. All changes made since the last save operation are lost.</source>
        <translation>Эта опция используется, чтобы вернуть текущий файл базы данных в его последнее сохранённое состояние. Все изменения, сделаные с последней операции сохранения теряются.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1435"/>
        <location filename="../MainWindow.ui" line="1438"/>
        <source>Write changes to the database file</source>
        <translation>Записать изменения в файл базы данных</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1441"/>
        <source>This option is used to save changes to the database file.</source>
        <translation>Эта опция используется, чтобы сохранить изменения в файле базы данных.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1444"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1455"/>
        <source>Compact &amp;Database...</source>
        <translation>&amp;Уплотнить базу данных...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1458"/>
        <source>Compact the database file, removing space wasted by deleted records</source>
        <translation>Уплотнить базу данных, удаляя пространство, занимаемое удалёнными записями</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1461"/>
        <location filename="../MainWindow.ui" line="1464"/>
        <source>Compact the database file, removing space wasted by deleted records.</source>
        <translation>Уплотнить базу данных, удаляя пространство, занимаемое удалёнными записями.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1472"/>
        <source>E&amp;xit</source>
        <translation>&amp;Выход</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1475"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1486"/>
        <source>Import data from an .sql dump text file into a new or existing database.</source>
        <translation>Импортировать данные из текстового файла sql в новую или существующую базу данных.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1489"/>
        <source>This option lets you import data from an .sql dump text file into a new or existing database. SQL dump files can be created on most database engines, including MySQL and PostgreSQL.</source>
        <translation>Эта опция позволяет импортировать данные из текстового файла sql в новую или существующую базу данных. Файл SQL может быть создан на большинстве движков баз данных, включая MySQL и PostgreSQL.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1500"/>
        <source>Open a wizard that lets you import data from a comma separated text file into a database table.</source>
        <translation>Открыть мастер, который позволяет импортировать данные из файла CSV в таблицу базы данных.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1503"/>
        <source>Open a wizard that lets you import data from a comma separated text file into a database table. CSV files can be created on most database and spreadsheet applications.</source>
        <translation>Открыть мастер, который позволяет импортировать данные из файла CSV в таблицу базы данных. Файлы CSV могут быть созданы в большинстве приложений баз данных и  электронных таблиц.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1514"/>
        <source>Export a database to a .sql dump text file.</source>
        <translation>Экспортировать базу данных в текстовый файл .sql.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1517"/>
        <source>This option lets you export a database to a .sql dump text file. SQL dump files contain all data necessary to recreate the database on most database engines, including MySQL and PostgreSQL.</source>
        <translation>Эта опция позволяет экспортировать базу данных в текстовый файл .sql. Файлы SQL содержат все данные, необходимые для создания базы данных в большистве движков баз данных, включая MySQL и PostgreSQL.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1528"/>
        <source>Export a database table as a comma separated text file.</source>
        <translation>Экспортировать таблицу базы данных как CSV текстовый файл.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1531"/>
        <source>Export a database table as a comma separated text file, ready to be imported into other database or spreadsheet applications.</source>
        <translation>Экспортировать таблицу базы данных как CSV текстовый файл, готовый для импортирования в другие базы данных или приложения электронных таблиц.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1549"/>
        <source>Open the Create Table wizard, where it is possible to define the name and fields for a new table in the database</source>
        <translation>Открыть мастер создания таблиц, где возможно определить имя и поля для новой таблиы в базе данных</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1570"/>
        <source>Open the Delete Table wizard, where you can select a database table to be dropped.</source>
        <translation>Открыть мастер удаления таблицы, где можно выбрать таблицу базы данных для удаления.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1588"/>
        <source>Open the Modify Table wizard, where it is possible to rename an existing table. It is also possible to add or delete fields form a table, as well as modify field names and types.</source>
        <translation>Открыть мастер изменения таблицы, где возможно переименовать существующую таблиц. Можно добавить или удалить поля таблицы, так же изменять имена полей и типы.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1606"/>
        <source>Open the Create Index wizard, where it is possible to define a new index on an existing database table.</source>
        <translation>Открыть мастер создания интекса, в котором можно определить новый индекс для существующей таблиц базы данных.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1618"/>
        <source>&amp;Preferences...</source>
        <translation>&amp;Настройки...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1621"/>
        <location filename="../MainWindow.ui" line="1624"/>
        <source>Open the preferences window.</source>
        <translation>Открыть окно настроек.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1639"/>
        <source>&amp;DB Toolbar</source>
        <translation>&amp;Панель инструментов БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1642"/>
        <source>Shows or hides the Database toolbar.</source>
        <translation>Показать или скрыть панель инструментов База данных.</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1660"/>
        <source>Shift+F1</source>
        <translation>Shift+F1</translation>
    </message>
    <message>
        <source>&amp;About...</source>
        <translation type="vanished">О &amp;программе...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1676"/>
        <source>&amp;Recently opened</source>
        <translation>&amp;Недавно открываемые</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1685"/>
        <source>Open &amp;tab</source>
        <translation>Открыть &amp;вкладку</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1645"/>
        <location filename="../MainWindow.ui" line="1691"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="29"/>
        <source>Database Structure</source>
        <translation>Структура БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="69"/>
        <source>This is the structure of the opened database.
You can drag SQL statements from an object row and drop them into other applications or into another instance of &apos;DB Browser for SQLite&apos;.
</source>
        <translation>Это структура открытой БД.
Вы можете перетаскивать операторы SQL из строки &quot;объект&quot; и переносить их в другие приложения или в другой экземпляр &quot;Обозреватель для SQLite&quot;.
</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="94"/>
        <source>Browse Data</source>
        <translation>Данные</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="146"/>
        <source>Refresh the data in the selected table</source>
        <translation>Обновить данные в выбранной таблице</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="414"/>
        <source>Edit Pragmas</source>
        <translation>Прагмы</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="929"/>
        <source>Execute SQL</source>
        <translation>SQL</translation>
    </message>
    <message>
        <source>Edit Database Cell</source>
        <translation type="obsolete">Редактирование ячейки БД</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1106"/>
        <source>SQL &amp;Log</source>
        <translation>&amp;Журнал SQL</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1124"/>
        <source>Show S&amp;QL submitted by</source>
        <translation>По&amp;казывать SQL, выполненный</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1222"/>
        <source>&amp;Plot</source>
        <translation>&amp;График</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1408"/>
        <source>&amp;Revert Changes</source>
        <translation>&amp;Отменить изменения</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1432"/>
        <source>&amp;Write Changes</source>
        <translation>&amp;Записать изменения</translation>
    </message>
    <message>
        <source>Compact &amp;Database</source>
        <translation type="vanished">&amp;Уплотнить базу данных</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1483"/>
        <source>&amp;Database from SQL file...</source>
        <translation>&amp;База данных из файла SQL...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1497"/>
        <source>&amp;Table from CSV file...</source>
        <translation>&amp;Таблицы из файла CSV...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1511"/>
        <source>&amp;Database to SQL file...</source>
        <translation>Базу &amp;данных в файл SQL...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1525"/>
        <source>&amp;Table(s) as CSV file...</source>
        <translation>&amp;Таблицы в файл CSV...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1546"/>
        <source>&amp;Create Table...</source>
        <translation>&amp;Создать таблицу...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1564"/>
        <source>&amp;Delete Table...</source>
        <translation>&amp;Удалить таблицу...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1585"/>
        <source>&amp;Modify Table...</source>
        <translation>&amp;Изменить таблицу...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1603"/>
        <source>Create &amp;Index...</source>
        <translation>Создать и&amp;ндекс...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1657"/>
        <source>W&amp;hat&apos;s This?</source>
        <translation>Что &amp;это такое?</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1700"/>
        <source>&amp;Execute SQL</source>
        <translation>В&amp;ыполнить код SQL</translation>
    </message>
    <message>
        <source>Execute SQL</source>
        <translation type="vanished">Выполнить код SQL</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1715"/>
        <source>Open SQL file</source>
        <translation>Открыть файл SQL</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1727"/>
        <location filename="../MainWindow.ui" line="1930"/>
        <location filename="../MainWindow.ui" line="1933"/>
        <source>Save SQL file</source>
        <translation>Сохранить файл SQL</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1751"/>
        <source>Execute current line</source>
        <translation>Выполнить текущую строку</translation>
    </message>
    <message>
        <source>Execute current line</source>
        <translation type="obsolete">Выполнить текущую строку</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="268"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1768"/>
        <source>Export as CSV file</source>
        <translation>Экспортировать в файл CSV</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1771"/>
        <source>Export table as comma separated values file</source>
        <translation>Экспортировать таблицу как CSV файл</translation>
    </message>
    <message>
        <source>&amp;Wiki...</source>
        <translation type="vanished">В&amp;ики...</translation>
    </message>
    <message>
        <source>Bug &amp;report...</source>
        <translation type="vanished">&amp;Отчёт об ошибке...</translation>
    </message>
    <message>
        <source>Web&amp;site...</source>
        <translation type="vanished">&amp;Веб-сайт...</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1843"/>
        <location filename="../MainWindow.ui" line="1846"/>
        <source>Save the current session to a file</source>
        <translation>Сохранить текущее состояние в файл </translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1864"/>
        <location filename="../MainWindow.ui" line="1867"/>
        <source>Load a working session from a file</source>
        <translation>Загрузить рабочее состояние из файла</translation>
    </message>
    <message>
        <source>&amp;Set Encryption</source>
        <translation type="vanished">Ши&amp;фрование</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1954"/>
        <source>Copy Create statement</source>
        <translation>Копировать CREATE выражение</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1957"/>
        <source>Copy the CREATE statement of the item to the clipboard</source>
        <translation>Копировать CREATE выражение элемента в буффер обмена</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="172"/>
        <source>Ctrl+Return</source>
        <translation>Ctrl+Return</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="253"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="2361"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="258"/>
        <source>Ctrl+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="263"/>
        <source>Ctrl+I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="292"/>
        <source>Encrypted</source>
        <translation>Зашифровано</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="299"/>
        <source>Read only</source>
        <translation>Только для чтения</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="300"/>
        <source>Database file is read only. Editing the database is disabled.</source>
        <translation>База данных только для чтения. Редактирование запрещено.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="306"/>
        <source>Database encoding</source>
        <translation>Кодировка базы данных</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="293"/>
        <source>Database is encrypted using SQLCipher</source>
        <translation>База данных зашифрована с использованием SQLCipher</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="414"/>
        <location filename="../MainWindow.cpp" line="2841"/>
        <source>Choose a database file</source>
        <translation>Выбрать файл базы данных</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="455"/>
        <source>Could not open database file.
Reason: %1</source>
        <translation>Не удалось открыть файл базы данных.
Причина:%1</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="467"/>
        <location filename="../MainWindow.cpp" line="1650"/>
        <location filename="../MainWindow.cpp" line="2725"/>
        <source>Choose a filename to save under</source>
        <translation>Выбрать имя, под которым сохранить данные</translation>
    </message>
    <message>
        <source>Error adding record:
</source>
        <translation type="vanished">Ошибка добавления записи:</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="812"/>
        <source>Error deleting record:
%1</source>
        <translation>Ошибка удаления записи: %1</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="821"/>
        <source>Please select a record first</source>
        <translation>Сначала выберите запись</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="909"/>
        <source>%1 - %2 of %3</source>
        <translation>%1 - %2 из %3</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="946"/>
        <location filename="../MainWindow.cpp" line="960"/>
        <source>There is no database opened. Please open or create a new database file.</source>
        <translation>Нет открытой базы данных. Откройте или создайте файл новой базы данных.</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the %1 &apos;%2&apos;?
All data associated with the %1 will be lost.</source>
        <translation type="vanished">Хотите удалить %1 &apos;%2&apos;?
Все данные, связанные с %1, будут потеряны.</translation>
    </message>
    <message>
        <source>Error: could not delete the %1. Message from database engine:
%2</source>
        <translation type="vanished">Ошибка: невозмножно удалить %1. Сообщение из движка базы данных: %2</translation>
    </message>
    <message>
        <source>There is no database opened.</source>
        <translation type="vanished">Нет открытой базы данных.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2296"/>
        <source>A new DB Browser for SQLite version is available (%1.%2.%3).&lt;br/&gt;&lt;br/&gt;Please download at &lt;a href=&apos;%4&apos;&gt;%4&lt;/a&gt;.</source>
        <translation>Вышла новая версия Обозревателя для SQLite (%1.%2.%3).&lt;br/&gt;&lt;br/&gt;Она доступна для скачивания по адресу &lt;a href=&apos;%4&apos;&gt;%4&lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2472"/>
        <location filename="../MainWindow.cpp" line="2726"/>
        <source>DB Browser for SQLite project file (*.sqbpro)</source>
        <translation>Файл проекта Обозревателя для SQLite (*.sqbpro)</translation>
    </message>
    <message>
        <source>Error executing query: %1</source>
        <translation type="vanished">Ошибка выполнения запроса: %1</translation>
    </message>
    <message>
        <source>%1 rows returned in %2ms from: %3</source>
        <translation type="vanished">%1 строки возвращены за %2мс из: %3</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1402"/>
        <source>, %1 rows affected</source>
        <translation>, %1 строк изменено</translation>
    </message>
    <message>
        <source>Query executed successfully: %1 (took %2ms%3)</source>
        <translation type="vanished">Запрос успешно выполнен: %1 (заняло %2мс%3)</translation>
    </message>
    <message>
        <source>Choose a text file</source>
        <translation type="vanished">Выбрать текстовый файл</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1526"/>
        <source>Text files(*.csv *.txt);;All files(*)</source>
        <translation>Текстовые файлы(*.csv *.txt);;Все файлы(*)</translation>
    </message>
    <message>
        <source>Import completed</source>
        <translation type="vanished">Импорт завершён</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1600"/>
        <source>Error while saving the database file. This means that not all changes to the database were saved. You need to resolve the following error first.

%1</source>
        <translation>Ошибка при сохранении файла базы данных. Это означает, что не все изменения в базе данных были сохранены. Сначала вам необходимо разрешить следующую ошибку.

%1</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1609"/>
        <source>Are you sure you want to undo all changes made to the database file &apos;%1&apos; since the last save?</source>
        <translation>Отменить все изменения, сделанные в файле базы данных &apos;%1&apos; после последнего сохранения?</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1633"/>
        <source>Choose a file to import</source>
        <translation>Выберать файл для импорта</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1634"/>
        <location filename="../MainWindow.cpp" line="2114"/>
        <location filename="../MainWindow.cpp" line="2174"/>
        <source>Text files(*.sql *.txt);;All files(*)</source>
        <translation>Текстовые файлы(*.sql *.txt);;Все файлы(*)</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1644"/>
        <source>Do you want to create a new database file to hold the imported data?
If you answer no we will attempt to import the data in the SQL file to the current database.</source>
        <translation>Создать новый файл базы данных, чтобы сохранить импортированные данные?
Если ответить Нет, будет выполнена попытка импортировать данные файла SQL в текущую базу данных.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1654"/>
        <source>File %1 already exists. Please choose a different name.</source>
        <translation>Файл %1 уже существует. Выберите другое имя.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1676"/>
        <source>Error importing data: %1</source>
        <translation>Ошибка импортирования данных: %1</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1680"/>
        <source>Import completed.</source>
        <translation>Импорт завершён.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1744"/>
        <source>Delete View</source>
        <translation>Удалить представление</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1745"/>
        <source>Modify View</source>
        <translation>Модифицировать представление</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1747"/>
        <source>Delete Trigger</source>
        <translation>Удалить триггер</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1748"/>
        <source>Modify Trigger</source>
        <translation>Модифицировать триггер</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1750"/>
        <source>Delete Index</source>
        <translation>Удалить индекс</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2471"/>
        <source>Choose a project file to open</source>
        <translation>Выберите файл проекта для открытия</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2580"/>
        <source>This project file is using an old file format because it was created using DB Browser for SQLite version 3.10 or lower. Loading this file format is still fully supported but we advice you to convert all your project files to the new file format because support for older formats might be dropped at some point in the future. You can convert your files by simply opening and re-saving them.</source>
        <translation>Этот файл проекта использует старый формат файла, потому что он был создан с использованием DB Browser для SQLite версии 3.10 или ниже. Загрузка этого формата по-прежнему полностью поддерживается, но мы советуем вам преобразовать все ваши файлы проекта в новый формат файла, поскольку поддержка более старых форматов может быть удалена в какой-то момент в будущем. Вы можете конвертировать ваши файлы, просто открывая и повторно сохраняя их.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3022"/>
        <source>Duplicate records</source>
        <translation>Дублированные записи</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3027"/>
        <source>Ctrl+&quot;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3202"/>
        <source>Please enter a pseudo-primary key in order to enable editing on this view. This should be the name of a unique column in the view.</source>
        <translation>Пожалуйста, введите псевдо-первичный ключ, чтобы разрешить редактирование в этом представлении. Это должно быть имя уникального столбца в представлении.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3126"/>
        <source>Please choose a new encoding for this table.</source>
        <translation>Пожалуйста выбирите новую кодировку для данной таблицы.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1058"/>
        <source>Error checking foreign keys after table modification. The changes will be reverted.</source>
        <translation>Ошибка проверки внешних ключей после изменения таблицы. Изменения будут отменены.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1061"/>
        <source>This table did not pass a foreign-key check.&lt;br/&gt;You should run &apos;Tools | Foreign-Key Check&apos; and fix the reported issues.</source>
        <translation>Эта таблица не прошла проверку внешнего ключа. &lt;br/&gt; Вы должны запустить &quot;Инструменты | Проверка внешнего ключа&quot;и исправить сообщенные проблемы.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3124"/>
        <source>Please choose a new encoding for all tables.</source>
        <translation>Пожалуйста выбирите новую кодировку для всех таблиц.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3129"/>
        <source>%1
Leave the field empty for using the database encoding.</source>
        <translation>%1
Оставьте это поле пустым если хотите чтобы использовалась кодировка по умолчанию.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3141"/>
        <source>This encoding is either not valid or not supported.</source>
        <translation>Неверная кодировка либо она не поддерживается.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Отменить</translation>
    </message>
    <message>
        <location filename="../MainWindow.ui" line="1567"/>
        <location filename="../MainWindow.cpp" line="1753"/>
        <source>Delete Table</source>
        <translation>Удалить таблицу</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1809"/>
        <source>&amp;%1 %2</source>
        <translation>&amp;%1 %2</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2032"/>
        <source>Setting PRAGMA values will commit your current transaction.
Are you sure?</source>
        <translation>Установка значений PRAGMA завершит текущую транзакцию. Установить значения?</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1327"/>
        <source>Execution aborted by user</source>
        <translation>Выполнение прервано пользователем</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="488"/>
        <source>In-Memory database</source>
        <translation>БД в памяти</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="902"/>
        <source>determining row count...</source>
        <translation>определяем количество строк...</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="905"/>
        <source>%1 - %2 of &gt;= %3</source>
        <translation>%1 - %2 из &gt;= %3</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="985"/>
        <source>Are you sure you want to delete the table &apos;%1&apos;?
All data associated with the table will be lost.</source>
        <translation>Вы действительно хотите удалить таблицу &apos;%1&apos;?
Все данные, связанные с таблицей, будут потеряны.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="987"/>
        <source>Are you sure you want to delete the view &apos;%1&apos;?</source>
        <translation>Вы действительно хотите удалить представление &apos;%1&apos;?</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="989"/>
        <source>Are you sure you want to delete the trigger &apos;%1&apos;?</source>
        <translation>Вы действительно хотите удалить триггер &apos;%1&apos;?</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="991"/>
        <source>Are you sure you want to delete the index &apos;%1&apos;?</source>
        <translation>Вы действительно хотите удалить индекс &apos;%1&apos;?</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1002"/>
        <source>Error: could not delete the table.</source>
        <translation>Ошибка: не удалось удалить таблицу.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1004"/>
        <source>Error: could not delete the view.</source>
        <translation>Ошибка: не удалось удалить представление.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1006"/>
        <source>Error: could not delete the trigger.</source>
        <translation>Ошибка: не удалось удалить триггер.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1008"/>
        <source>Error: could not delete the index.</source>
        <translation>Ошибка: не удалось удалить индекс.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1010"/>
        <source>Message from database engine:
%1</source>
        <translation>Сообщение от СУБД:
%1</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1039"/>
        <source>Editing the table requires to save all pending changes now.
Are you sure you want to save the database?</source>
        <translation>Для редактирования таблицы необходимо сохранить все ожидающие изменения сейчас.
Вы действительно хотите сохранить БД?</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1224"/>
        <source>-- EXECUTING SELECTION IN &apos;%1&apos;
--</source>
        <translation>-- ВЫПОЛНЕНИЕ ВЫБОРКИ В &apos;%1&apos;
--</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1247"/>
        <source>-- EXECUTING LINE IN &apos;%1&apos;
--</source>
        <translation>-- ВЫПОЛНЕНИЕ СТРОКИ В &apos;%1&apos;
--</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1255"/>
        <source>-- EXECUTING ALL IN &apos;%1&apos;
--</source>
        <translation>-- ВЫПОЛНЕНИЕ ВСЕ В &apos;%1&apos;
--</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1319"/>
        <source>Setting PRAGMA values or vacuuming will commit your current transaction.
Are you sure?</source>
        <translation>Установка значений PRAGMA или вакуумирования приведет к фиксации текущей транзакции.
Уверены ли вы?</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1347"/>
        <source>executing query</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1384"/>
        <source>%1 rows returned in %2ms</source>
        <translation>%1 строк возвращено за %2мс</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1408"/>
        <source>query executed successfully. Took %1ms%2</source>
        <translation>запрос успешно выполнен. Заняло %1мс%2</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1447"/>
        <source>-- At line %1:
%4
-- Result: %3</source>
        <translation>-- Строка %1:
%4
-- Результат: %3</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1525"/>
        <source>Choose text files</source>
        <translation>Выберите текстовые файлы</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1678"/>
        <source>Import completed. Some foreign key constraints are violated. Please fix them before saving.</source>
        <translation>Импорт завершен. Нарушены некоторые ограничения внешних ключей. Пожалуйста, исправьте их перед сохранением.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1751"/>
        <source>Modify Index</source>
        <translation>Модифицировать Индекс</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="1754"/>
        <source>Modify Table</source>
        <translation>Модифицировать Таблицу</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2113"/>
        <source>Select SQL file to open</source>
        <translation>Выбрать файл SQL для октрытия</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2122"/>
        <source>Couldn&apos;t read file: %1.</source>
        <translation>Не удалось прочитать файл:%1.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2160"/>
        <source>Couldn&apos;t save file: %1.</source>
        <translation>Не удалось сохранить файл:%1.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2173"/>
        <source>Select file name</source>
        <translation>Выбрать имя файла</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2198"/>
        <source>Select extension file</source>
        <translation>Выбрать расширение файла</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2199"/>
        <source>Extensions(*.so *.dll);;All files(*)</source>
        <translation>Расширения(*.so *.dll);;Все файлы(*)</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2205"/>
        <source>Extension successfully loaded.</source>
        <translation>Расширение успешно загружено.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2207"/>
        <source>Error loading extension: %1</source>
        <translation>Ошибка загрузки расширения: %1</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2292"/>
        <location filename="../MainWindow.cpp" line="2576"/>
        <source>Don&apos;t show again</source>
        <translation>Не показывать снова</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="2295"/>
        <source>New version available.</source>
        <translation>Доступна новая версия.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3302"/>
        <source>Collation needed! Proceed?</source>
        <translation>Нужно выполнить сопоставление! Продолжить?</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3303"/>
        <source>A table in this database requires a special collation function &apos;%1&apos; that this application can&apos;t provide without further knowledge.
If you choose to proceed, be aware bad things can happen to your database.
Create a backup!</source>
        <translation>Таблица в базе данных требует выполнения специальной функции сопоставления &apos;%1&apos;.
Если вы продолжите, то возможна порча вашей базы данных.
Создайте резервную копию!</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3308"/>
        <source>creating collation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3317"/>
        <source>Set a new name for the SQL tab. Use the &apos;&amp;&amp;&apos; character to allow using the following character as a keyboard shortcut.</source>
        <translation>Задайте новое имя для вкладки SQL. Используйте символ &apos;&amp;&amp;&apos;, чтобы разрешить использование следующего символа в качестве сочетания клавиш.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3360"/>
        <source>Please specify the view name</source>
        <translation>Укажите имя представления</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3364"/>
        <source>There is already an object with that name. Please choose a different name.</source>
        <translation>Объект с указанным именем уже существует. Выберите другое имя.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3371"/>
        <source>View successfully created.</source>
        <translation>Представление успешно создано.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3373"/>
        <source>Error creating view: %1</source>
        <translation>Ошибка создания представления: %1</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3388"/>
        <source>There is no filter set for this table. View will not be created.</source>
        <translation>Для этой таблицы не установлен фильтр. Представление не будет создано.</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3426"/>
        <source>Delete Records</source>
        <translation>Удалить Записи</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3433"/>
        <source>This action will open a new SQL tab for running:</source>
        <translation>Это действие откроет новую вкладку SQL для запуска:</translation>
    </message>
    <message>
        <location filename="../MainWindow.cpp" line="3435"/>
        <source>Press Help for opening the corresponding SQLite reference page.</source>
        <translation>Нажмите &quot;Справка&quot; для открытия соответствующей справочной страницы SQLite.</translation>
    </message>
    <message>
        <source>Choose a axis color</source>
        <translation type="vanished">Выбрать цвет осей</translation>
    </message>
    <message>
        <source>PNG(*.png);;JPG(*.jpg);;PDF(*.pdf);;BMP(*.bmp);;All Files(*)</source>
        <translation type="vanished">PNG(*.png);;JPG(*.jpg);;PDF(*.pdf);;BMP(*.bmp);;Все файлы(*)</translation>
    </message>
    <message>
        <source>Choose a file to open</source>
        <translation type="vanished">Выбрать файл для открытия</translation>
    </message>
    <message>
        <source>Invalid file format.</source>
        <translation type="vanished">Ошибочный формат файла.</translation>
    </message>
</context>
<context>
    <name>NullLineEdit</name>
    <message>
        <location filename="../AddRecordDialog.cpp" line="39"/>
        <source>Set to NULL</source>
        <translation>Установить в NULL</translation>
    </message>
    <message>
        <location filename="../AddRecordDialog.cpp" line="43"/>
        <source>Alt+Del</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PlotDock</name>
    <message>
        <location filename="../PlotDock.ui" line="14"/>
        <source>Plot</source>
        <translation>График</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="30"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This pane shows the list of columns of the currently browsed table or the just executed query. You can select the columns that you want to be used as X or Y axis for the plot pane below. The table shows detected axis type that will affect the resulting plot. For the Y axis you can only select numeric columns, but for the X axis you will be able to select:&lt;/p&gt;&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Date/Time&lt;/span&gt;: strings with format &amp;quot;yyyy-MM-dd hh:mm:ss&amp;quot; or &amp;quot;yyyy-MM-ddThh:mm:ss&amp;quot;&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Date&lt;/span&gt;: strings with format &amp;quot;yyyy-MM-dd&amp;quot;&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Time&lt;/span&gt;: strings with format &amp;quot;hh:mm:ss&amp;quot;&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Label&lt;/span&gt;: other string formats. Selecting this column as X axis will produce a Bars plot with the column values as labels for the bars&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Numeric&lt;/span&gt;: integer or real values&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;Double-clicking the Y cells you can change the used color for that graph.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;На этой панели отображается список столбцов текущей просматриваемой таблицы или только что выполненного запроса. Вы можете выбрать столбцы, которые вы хотите использовать в качестве оси X или Y для графика ниже. В таблице показан тип обнаруженной оси, который повлияет на итоговый график. Для оси Y вы можете выбирать только числовые столбцы, но для оси X вы можете выбрать:&lt;/p&gt;&lt;ul style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Дата/Время&lt;/span&gt;: строки с форматом &amp;quot;гггг-ММ-дд чч:мм:сс&amp;quot; или &amp;quot;гггг-ММ-ддTчч:мм:сс&amp;quot;&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Дата&lt;/span&gt;: строки с форматом &amp;quot;гггг-ММ-дд&amp;quot;&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Время&lt;/span&gt;: строки с форматом &amp;quot;чч:мм:сс&amp;quot;&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Текст&lt;/span&gt;: строки лубого формата. Выбор этого столбца по оси X приведет к созданию графика Баров, со значениями столбцов в качестве меток для баров&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Числа&lt;/span&gt;: целочисленные или вещественные значения&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;Дважды щелкните по ячейкам Y, вы можете изменить используемый цвет для этого графика.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="46"/>
        <source>Columns</source>
        <translation>Столбцы</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="51"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="56"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <source>_</source>
        <translation type="obsolete">_</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="61"/>
        <source>Axis Type</source>
        <translation>Ось</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="73"/>
        <source>Here is a plot drawn when you select the x and y values above.

Click on points to select them in the plot and in the table. Ctrl+Click for selecting a range of points.

Use mouse-wheel for zooming and mouse drag for changing the axis range.

Select the axes or axes labels to drag and zoom only in that orientation.</source>
        <translation>Вот график, нарисованный, когда вы выбираете значения x и y выше.

Нажмите на пункты, чтобы выбрать их на графике и в таблице. Ctrl + Click для выбора диапазона точек.

Используйте колесико мыши для масштабирования и перетаскивания мышью для изменения диапазона осей.

Выберите метки осей или осей для перетаскивания и масштабирования только в этой ориентации.</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="89"/>
        <source>Line type:</source>
        <translation>Линия:</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="118"/>
        <location filename="../PlotDock.ui" line="165"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="123"/>
        <source>Line</source>
        <translation>Обычная</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="128"/>
        <source>StepLeft</source>
        <translation>Ступенчатая, слева</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="133"/>
        <source>StepRight</source>
        <translation>Ступенчатая, справа</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="138"/>
        <source>StepCenter</source>
        <translation>Ступенчатая, по центру</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="143"/>
        <source>Impulse</source>
        <translation>Импульс</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="151"/>
        <source>Point shape:</source>
        <translation>Отрисовка точек:</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="170"/>
        <source>Cross</source>
        <translation>Крест</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="175"/>
        <source>Plus</source>
        <translation>Плюс</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="180"/>
        <source>Circle</source>
        <translation>Круг</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="185"/>
        <source>Disc</source>
        <translation>Диск</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="190"/>
        <source>Square</source>
        <translation>Квадрат</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="195"/>
        <source>Diamond</source>
        <translation>Ромб</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="200"/>
        <source>Star</source>
        <translation>Звезда</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="205"/>
        <source>Triangle</source>
        <translation>Треугольник</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="210"/>
        <source>TriangleInverted</source>
        <translation>Треугольник перевернутый</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="215"/>
        <source>CrossSquare</source>
        <translation>Крест в квадрате</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="220"/>
        <source>PlusSquare</source>
        <translation>Плюс в квадрате</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="225"/>
        <source>CrossCircle</source>
        <translation>Крест в круге</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="230"/>
        <source>PlusCircle</source>
        <translation>Плюс в круге</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="235"/>
        <source>Peace</source>
        <translation>Мир</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="256"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Save current plot...&lt;/p&gt;&lt;p&gt;File format chosen by extension (png, jpg, pdf, bmp)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Сохранить текущий график...&lt;/p&gt;&lt;p&gt;Формат файла выбирается расширением (png, jpg, pdf, bmp)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="259"/>
        <source>Save current plot...</source>
        <translation>Сохранить текущий график...</translation>
    </message>
    <message>
        <location filename="../PlotDock.ui" line="285"/>
        <location filename="../PlotDock.cpp" line="448"/>
        <source>Load all data and redraw plot</source>
        <translation>Загрузить все данные и перерисовать</translation>
    </message>
    <message>
        <source>Load all data. This has only an effect if not all data has been fetched from the table yet due to the partial fetch mechanism.</source>
        <translation type="obsolete">Загружать все данные. Имеет эффект лишь если не все данные подгружены.</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="204"/>
        <location filename="../PlotDock.cpp" line="417"/>
        <location filename="../PlotDock.cpp" line="430"/>
        <source>Row #</source>
        <translation>Строка #</translation>
    </message>
    <message>
        <source>Choose a axis color</source>
        <translation type="obsolete">Выбрать цвет осей</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="54"/>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="61"/>
        <source>Print...</source>
        <translation>Печать...</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="68"/>
        <source>Show legend</source>
        <translation>Легенда</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="74"/>
        <source>Stacked bars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="153"/>
        <source>Date/Time</source>
        <translation>Дата/Время</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="156"/>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="159"/>
        <source>Time</source>
        <translation>Время</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="162"/>
        <location filename="../PlotDock.cpp" line="206"/>
        <source>Numeric</source>
        <translation>Число</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="165"/>
        <source>Label</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="169"/>
        <source>Invalid</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="443"/>
        <source>Load all data and redraw plot.
Warning: not all data has been fetched from the table yet due to the partial fetch mechanism.</source>
        <translation>Загружает все данные и перерисовыет график.
Предупреждение: не все данные были получены из таблицы из-за механизма частичной выборки.</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="578"/>
        <source>Choose an axis color</source>
        <translation>Выберите цвет оси</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="610"/>
        <source>Choose a filename to save under</source>
        <translation>Выбрать имя файла, под которым сохранить данные</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="611"/>
        <source>PNG(*.png);;JPG(*.jpg);;PDF(*.pdf);;BMP(*.bmp);;All Files(*)</source>
        <translation>PNG(*.png);;JPG(*.jpg);;PDF(*.pdf);;BMP(*.bmp);;Все файлы(*)</translation>
    </message>
    <message>
        <location filename="../PlotDock.cpp" line="648"/>
        <source>There are curves in this plot and the selected line style can only be applied to graphs sorted by X. Either sort the table or query by X to remove curves or select one of the styles supported by curves: None or Line.</source>
        <translation>На этом графике есть кривые, и выбранный стиль линии может применяться только к графикам, отсортированным по X. Либо сортируйте таблицу или запрос по X, чтобы удалить кривые, либо выберите один из стилей, поддерживаемых кривыми: None или Line.</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Отменить</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../PreferencesDialog.ui" line="14"/>
        <source>Preferences</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="243"/>
        <source>&amp;Database</source>
        <translation>&amp;База данных</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="252"/>
        <source>Database &amp;encoding</source>
        <translation>&amp;Кодировка базы данных</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="276"/>
        <source>Open databases with foreign keys enabled.</source>
        <translation>Открывать базы данных с включенными внешними ключами.</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="279"/>
        <source>&amp;Foreign keys</source>
        <translation>&amp;Внешние ключи</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="198"/>
        <location filename="../PreferencesDialog.ui" line="218"/>
        <location filename="../PreferencesDialog.ui" line="289"/>
        <location filename="../PreferencesDialog.ui" line="309"/>
        <location filename="../PreferencesDialog.ui" line="1128"/>
        <location filename="../PreferencesDialog.ui" line="1148"/>
        <location filename="../PreferencesDialog.ui" line="1168"/>
        <location filename="../PreferencesDialog.ui" line="1188"/>
        <source>enabled</source>
        <translation>включены</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="33"/>
        <source>Default &amp;location</source>
        <translation>&amp;Расположение
по умолчанию</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="85"/>
        <location filename="../PreferencesDialog.ui" line="1418"/>
        <location filename="../PreferencesDialog.ui" line="1474"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="27"/>
        <source>&amp;General</source>
        <translation>&amp;Общие</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="46"/>
        <source>Remember last location</source>
        <translation>Запоминать последнюю директорию</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="51"/>
        <source>Always use this location</source>
        <translation>Всегда открывать указанную</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="56"/>
        <source>Remember last location for session only</source>
        <translation>Запоминать последнюю директорию только для сессий</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="96"/>
        <source>Lan&amp;guage</source>
        <translation>&amp;Язык</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="208"/>
        <source>Automatic &amp;updates</source>
        <translation>&amp;Следить за обновлениями</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="366"/>
        <source>SQ&amp;L to execute after opening database</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="403"/>
        <source>Data &amp;Browser</source>
        <translation>Обозреватель &amp;данных</translation>
    </message>
    <message>
        <source>NULL fields</source>
        <translation type="vanished">NULL поля</translation>
    </message>
    <message>
        <source>&amp;Text</source>
        <translation type="vanished">&amp;Текст</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="296"/>
        <source>Remove line breaks in schema &amp;view</source>
        <translation>Удалить переводы строки в &amp;схеме данных</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="188"/>
        <source>Show remote options</source>
        <translation>Опции &quot;облака&quot;</translation>
    </message>
    <message>
        <source>Remote server</source>
        <translation type="vanished">Сервер</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="316"/>
        <source>Prefetch block si&amp;ze</source>
        <translation>Размер блока &amp;упреждающей выборки</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="336"/>
        <source>Advanced</source>
        <translation>Дополнительно</translation>
    </message>
    <message>
        <source>SQL to execute after opening database</source>
        <translation type="vanished">SQL, который нужно выполнить после открытия БД</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="392"/>
        <source>Default field type</source>
        <translation>Тип данных по умолчанию</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="411"/>
        <source>Font</source>
        <translation>Шрифт</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="417"/>
        <source>&amp;Font</source>
        <translation>&amp;Шрифт</translation>
    </message>
    <message>
        <source>Font si&amp;ze:</source>
        <translation type="vanished">Ра&amp;змер шрифта:</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="446"/>
        <source>Content</source>
        <translation>Содержимое</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="452"/>
        <source>Symbol limit in cell</source>
        <translation>Количество символов в ячейке</translation>
    </message>
    <message>
        <source>Field colors</source>
        <translation type="vanished">Цветовое оформление полей</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="544"/>
        <source>NULL</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="554"/>
        <source>Regular</source>
        <translation>Обычные</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="vanished">Текст</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="534"/>
        <source>Binary</source>
        <translation>Двоичные данные</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="954"/>
        <source>Background</source>
        <translation>Фон</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="743"/>
        <source>Filters</source>
        <translation>Фильтры</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="756"/>
        <source>Escape character</source>
        <translation>Символ экранирования</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="766"/>
        <source>Delay time (&amp;ms)</source>
        <translation>Время задержки (&amp;мс)</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="776"/>
        <source>Set the waiting time before a new filter value is applied. Can be set to 0 for disabling waiting.</source>
        <translation>Время задержки перед применением нового фильтра. Нулевое значение отключает ожидание.</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="792"/>
        <source>&amp;SQL</source>
        <translation>Р&amp;едактор SQL</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="805"/>
        <source>Settings name</source>
        <translation>Имя настроек</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="810"/>
        <source>Context</source>
        <translation>Контекст</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="815"/>
        <source>Colour</source>
        <translation>Цвет</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="820"/>
        <source>Bold</source>
        <translation>Жирный</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="825"/>
        <source>Italic</source>
        <translation>Курсив</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="830"/>
        <source>Underline</source>
        <translation>Подчёркивание</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="838"/>
        <source>Keyword</source>
        <translation>Ключевое слово</translation>
    </message>
    <message>
        <source>function</source>
        <translation type="vanished">функция</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="858"/>
        <source>Function</source>
        <translation>Функция</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="866"/>
        <source>Table</source>
        <translation>Таблица</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="886"/>
        <source>Comment</source>
        <translation>Комментарий</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="906"/>
        <source>Identifier</source>
        <translation>Идентификатор</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="926"/>
        <source>String</source>
        <translation>Строка</translation>
    </message>
    <message>
        <source>currentline</source>
        <translation type="vanished">текущаястрока</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="946"/>
        <source>Current line</source>
        <translation>Текущая строка</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="987"/>
        <source>SQL &amp;editor font size</source>
        <translation>Размер шрифта в &amp;редакторе SQL</translation>
    </message>
    <message>
        <source>SQL &amp;log font size</source>
        <translation type="vanished">Размер шрифта в &amp;журнале SQL</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1026"/>
        <source>Tab size</source>
        <translation>Размер табуляции</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="972"/>
        <source>SQL editor &amp;font</source>
        <translation>&amp;Шрифт в редакторе SQL</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1155"/>
        <source>Error indicators</source>
        <translation>Индикаторы ошибок</translation>
    </message>
    <message>
        <source>Enabling error indicators highlights the SQL code lines that caused errors during the last execution</source>
        <translation type="vanished">Подсветка в SQL коде строк, выполнение которых привело к ошибкам</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1175"/>
        <source>Hori&amp;zontal tiling</source>
        <translation>Гори&amp;зонтальное распределение</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1185"/>
        <source>If enabled the SQL code editor and the result table view are shown side by side instead of one over the other.</source>
        <translation>Если данная опция включена, то SQL редактор и результат запроса будут расположены рядом по горизонтали.</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1118"/>
        <source>Code co&amp;mpletion</source>
        <translation>Авто&amp;дополнение кода</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="128"/>
        <source>Toolbar style</source>
        <translation>Стиль тулбара</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="160"/>
        <source>Only display the icon</source>
        <translation>Только иконки</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="165"/>
        <source>Only display the text</source>
        <translation>Только текст</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="170"/>
        <source>The text appears beside the icon</source>
        <translation>Текст над иконкой</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="175"/>
        <source>The text appears under the icon</source>
        <translation>Текст под иконкой</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="180"/>
        <source>Follow the style</source>
        <translation>Указано в стиле</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="225"/>
        <source>DB file extensions</source>
        <translation>Расширения файлов БД</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="235"/>
        <source>Manage</source>
        <translation>Настроить</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="306"/>
        <source>When enabled, the line breaks in the Schema column of the DB Structure tab, dock and printed output are removed.</source>
        <translation>Когда отмечено, переносы строк в столбце &apos;Схема&apos; во вкладке &apos;Структура базы данных&apos;, &apos;док&apos; и &apos;печатный результат&apos; удаляются.</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="430"/>
        <source>Font si&amp;ze</source>
        <translation>Ра&amp;змер шрифта</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="484"/>
        <location filename="../PreferencesDialog.ui" line="488"/>
        <source>This is the maximum number of rows in a table for enabling the value completion based on current values in the column.
Can be set to 0 for disabling completion.</source>
        <translation>Максимальное количество строк в таблице для включения завершения значения на основе текущих значений в столбце.
Может быть установлено в 0 для отключения завершения.</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="502"/>
        <source>Row count threshold for completion</source>
        <translation>Порог количества строк для начала работы дополнения</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="515"/>
        <source>Field display</source>
        <translation>Отображение поля</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="521"/>
        <source>Displayed &amp;text</source>
        <translation>Отображаемый &amp;текст</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="580"/>
        <source>Text color</source>
        <translation>Цвет текста</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="606"/>
        <source>Background color</source>
        <translation>Цвет фона</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="709"/>
        <source>Preview only (N/A)</source>
        <translation>Предв. просмотр</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="962"/>
        <source>Foreground</source>
        <translation>Передний план</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1009"/>
        <source>SQL &amp;results font size</source>
        <translation>&amp;Размер шрифта</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1049"/>
        <source>&amp;Wrap lines</source>
        <translation>&amp;Перенос строк</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1060"/>
        <source>Never</source>
        <translation>Никогда</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1065"/>
        <source>At word boundaries</source>
        <translation>На границах слов</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1070"/>
        <source>At character boundaries</source>
        <translation>На границах символов</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1075"/>
        <source>At whitespace boundaries</source>
        <translation>На границах пробелов</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1083"/>
        <source>&amp;Quotes for identifiers</source>
        <translation>Обравмление &amp;идентификаторов</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1093"/>
        <source>Choose the quoting mechanism used by the application for identifiers in SQL code.</source>
        <translation>Выберите механизм обрамления, используемый приложением для идентификаторов в коде SQL.</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1100"/>
        <source>&quot;Double quotes&quot; - Standard SQL (recommended)</source>
        <translation>&quot;Двойные кавычки&quot; - Cтандартный SQL (рекомендуется)</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1105"/>
        <source>`Grave accents` - Traditional MySQL quotes</source>
        <translation>`Гравис` - Традиционные кавычки MySQL</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1110"/>
        <source>[Square brackets] - Traditional MS SQL Server quotes</source>
        <translation>[Квадратные скобки] - традиционные кавычки для MS SQL Server</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1135"/>
        <source>Keywords in &amp;UPPER CASE</source>
        <translation>Ключевые слова в &amp;ВЕРХНЕМ РЕГИСТРЕ</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1145"/>
        <source>When set, the SQL keywords are completed in UPPER CASE letters.</source>
        <translation>Когда отмечено, ключевые слова SQL будут в ВЕРХНЕМ РЕГИСТРЕ.</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1165"/>
        <source>When set, the SQL code lines that caused errors during the last execution are highlighted and the results frame indicates the error in the background</source>
        <translation>Когда установлено, строки кода SQL, вызвавшие ошибки во время последнего выполнения, подсвечиваются, а виджет результатов указывает на ошибку в фоновом режиме</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1198"/>
        <source>&amp;Extensions</source>
        <translation>Р&amp;асширения</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1204"/>
        <source>Select extensions to load for every database:</source>
        <translation>Выберите расширения, чтобы загружать их для каждой базы данных:</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1225"/>
        <source>Add extension</source>
        <translation>Добавить расширение</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1236"/>
        <source>Remove extension</source>
        <translation>Удалить расширение</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1264"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;While supporting the REGEXP operator SQLite doesn&apos;t implement any regular expression&lt;br/&gt;algorithm but calls back the running application. DB Browser for SQLite implements this&lt;br/&gt;algorithm for you to let you use REGEXP out of the box. However, as there are multiple possible&lt;br/&gt;implementations of this and you might want to use another one, you&apos;re free to disable the&lt;br/&gt;application&apos;s implementation and load your own by using an extension. Requires restart of the application.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Обозреватель для SQLite позволяет использовать оператор REGEXP &apos;из коробки&apos;. Но тем &lt;br/&gt;не менее, возможны несколько различных вариантов реализаций данного оператора и вы свободны &lt;br/&gt;в выборе какую именно использовать. Можно отключить нашу реализацию и использовать другую - &lt;br/&gt;путем загрузки соответсвующего расширения. В этом случае требуется перезагрузка приложения.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1267"/>
        <source>Disable Regular Expression extension</source>
        <translation>Отключить расширение Регулярных Выражений</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1274"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;SQLite provides an SQL function for loading extensions from a shared library file. Activate this if you want to use the &lt;span style=&quot; font-style:italic;&quot;&gt;load_extension()&lt;/span&gt; function from SQL code.&lt;/p&gt;&lt;p&gt;For security reasons, extension loading is turned off by default and must be enabled through this setting. You can always load extensions through the GUI, even though this option is disabled.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1277"/>
        <source>Allow loading extensions from SQL code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1285"/>
        <source>Remote</source>
        <translation>Удаленный сервер</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1281"/>
        <source>CA certificates</source>
        <translation>СА сертификаты</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1307"/>
        <location filename="../PreferencesDialog.ui" line="1374"/>
        <source>Subject CN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1310"/>
        <source>Common Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1315"/>
        <source>Subject O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1318"/>
        <source>Organization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1323"/>
        <location filename="../PreferencesDialog.ui" line="1390"/>
        <source>Valid from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1328"/>
        <location filename="../PreferencesDialog.ui" line="1395"/>
        <source>Valid to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1333"/>
        <location filename="../PreferencesDialog.ui" line="1400"/>
        <source>Serial number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1341"/>
        <source>Your certificates</source>
        <translation>Ваши сертификаты</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1369"/>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1377"/>
        <source>Subject Common Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1382"/>
        <source>Issuer CN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1385"/>
        <source>Issuer Common Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.ui" line="1446"/>
        <source>Clone databases into</source>
        <translation>Путь для клонируемых БД</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.cpp" line="60"/>
        <location filename="../PreferencesDialog.cpp" line="577"/>
        <source>Choose a directory</source>
        <translation>Выберать каталог</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.cpp" line="303"/>
        <source>The language will change after you restart the application.</source>
        <translation>Язык будет применен после перезапуска приложения.</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.cpp" line="370"/>
        <source>Select extension file</source>
        <translation>Выберать файл расширения</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.cpp" line="371"/>
        <source>Extensions(*.so *.dll);;All files(*)</source>
        <translation>Расширения(*.so *.dll);;Все файлы(*)</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.cpp" line="504"/>
        <source>Import certificate file</source>
        <translation>Импорт файла сертификата</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.cpp" line="512"/>
        <source>No certificates found in this file.</source>
        <translation>В данном файле не найден сертификат.</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.cpp" line="529"/>
        <source>Are you sure you want do remove this certificate? All certificate data will be deleted from the application settings!</source>
        <translation>Вы действительно хотите удалить этот сертификат? Все данные сертификата будут удалены из настроек приложения!</translation>
    </message>
    <message>
        <location filename="../PreferencesDialog.cpp" line="613"/>
        <source>Are you sure you want to clear all the saved settings?
All your preferences will be lost and default values will be used.</source>
        <translation>Вы действительно хотите удалить все сохраненные настройки?
Все ваши предпочтения будут потеряны, и будут использоваться значения по умолчанию.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../ImportCsvDialog.cpp" line="110"/>
        <source>Error importing data</source>
        <translation>Ошибка импортирования данных</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.cpp" line="112"/>
        <source> from record number %1</source>
        <translation> с записи номер %1</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.cpp" line="113"/>
        <source>.
%1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.cpp" line="127"/>
        <source>Importing CSV file...</source>
        <translation>Импортирование CSV файла...</translation>
    </message>
    <message>
        <location filename="../ImportCsvDialog.cpp" line="128"/>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <source>Decoding CSV file...</source>
        <translation type="vanished">Расшифровка CSV файла...</translation>
    </message>
    <message>
        <source>Collation needed! Proceed?</source>
        <translation type="vanished">Нужно выполнить сопоставление! Продолжить?</translation>
    </message>
    <message>
        <source>A table in this database requires a special collation function &apos;%1&apos; that this application can&apos;t provide without further knowledge.
If you choose to proceed, be aware bad things can happen to your database.
Create a backup!</source>
        <translation type="vanished">Таблица в базе данных требует выполнения специальной функции сопоставления &apos;%1&apos;.
Если вы продолжите, то возможна порча вашей базы данных.
Создайте резервную копию!</translation>
    </message>
    <message>
        <source>SQLite database files (*.db *.sqlite *.sqlite3 *.db3);;All files (*)</source>
        <translation type="obsolete">Файлы SQLite баз данных (*.db *.sqlite *.sqlite3 *.db3);;Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../FileDialog.cpp" line="76"/>
        <source>All files (*)</source>
        <translation>Все файлы (*)</translation>
    </message>
    <message>
        <location filename="../Settings.cpp" line="157"/>
        <source>SQLite database files (*.db *.sqlite *.sqlite3 *.db3)</source>
        <translation>Файлы SQLite баз данных (*.db *.sqlite *.sqlite3 *.db3)</translation>
    </message>
</context>
<context>
    <name>RemoteDatabase</name>
    <message>
        <location filename="../RemoteDatabase.cpp" line="107"/>
        <source>Error when connecting to %1.
%2</source>
        <translation>Ошибка во время подключения к %1.
%2</translation>
    </message>
    <message>
        <location filename="../RemoteDatabase.cpp" line="268"/>
        <source>Error opening remote file at %1.
%2</source>
        <translation>Ошибка открытия файла %1.
%2</translation>
    </message>
    <message>
        <location filename="../RemoteDatabase.cpp" line="341"/>
        <source>Error: Invalid client certificate specified.</source>
        <translation>Ошибка: Указан неверный сертификат клиента.</translation>
    </message>
    <message>
        <location filename="../RemoteDatabase.cpp" line="353"/>
        <source>Please enter the passphrase for this client certificate in order to authenticate.</source>
        <translation>Пожалуйста введите ключевую фразу для этого сертификата клиента.</translation>
    </message>
    <message>
        <location filename="../RemoteDatabase.cpp" line="377"/>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <location filename="../RemoteDatabase.cpp" line="381"/>
        <source>Uploading remote database to
%1</source>
        <translation>Загружается удаленная БД в
%1</translation>
    </message>
    <message>
        <location filename="../RemoteDatabase.cpp" line="383"/>
        <source>Downloading remote database from
%1</source>
        <translation>Скачивается удаленная БД из
%1</translation>
    </message>
    <message>
        <location filename="../RemoteDatabase.cpp" line="760"/>
        <source>The remote database has been updated since the last checkout. Do you want to update the local database to the newest version? Note that this discards any changes you have made locally! If you don&apos;t want to lose local changes, click No to open the local version.</source>
        <translation>Удаленная БД была обновлена со времени последней загрузки. Вы хотите обновить локальную базу данных до последней версии? Обратите внимание, что это отменяет любые изменения, внесенные вами локально! Если вы не хотите потерять локальные изменения, нажмите «Нет», чтобы открыть локальную версию.</translation>
    </message>
    <message>
        <location filename="../RemoteDatabase.cpp" line="400"/>
        <location filename="../RemoteDatabase.cpp" line="453"/>
        <source>Error: The network is not accessible.</source>
        <translation>Ошибка: сеть недоступна.</translation>
    </message>
    <message>
        <location filename="../RemoteDatabase.cpp" line="462"/>
        <source>Error: Cannot open the file for sending.</source>
        <translation>Ошибка: не удается открыть файл для отправки.</translation>
    </message>
    <message>
        <location filename="../RemoteDatabase.cpp" line="554"/>
        <source>Error opening local databases list.
%1</source>
        <translation>Ошибка при открытии списка локальных БД.
%1</translation>
    </message>
    <message>
        <location filename="../RemoteDatabase.cpp" line="572"/>
        <source>Error creating local databases list.
%1</source>
        <translation>Ошибка при создании списка локальных БД.
%1</translation>
    </message>
</context>
<context>
    <name>RemoteDock</name>
    <message>
        <location filename="../RemoteDock.ui" line="14"/>
        <source>Remote</source>
        <translation>Удаленный сервер</translation>
    </message>
    <message>
        <location filename="../RemoteDock.ui" line="22"/>
        <source>Identity</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../RemoteDock.ui" line="39"/>
        <source>Connect to the remote server using the currently selected identity. The correct server is taken from the identity as well.</source>
        <translation>Подключение к удаленному серверу, используя выбранный ID.</translation>
    </message>
    <message>
        <location filename="../RemoteDock.ui" line="42"/>
        <source>Go</source>
        <translation>Поехали</translation>
    </message>
    <message>
        <location filename="../RemoteDock.ui" line="66"/>
        <source>Push currently opened database to server</source>
        <translation>Отправить текущую БД на сервер</translation>
    </message>
    <message>
        <location filename="../RemoteDock.ui" line="79"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;In this pane, remote databases from dbhub.io website can be added to DB4S. First you need an identity:&lt;/p&gt;&lt;ol style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Login to the dbhub.io website (use your GitHub credentials or whatever you want)&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Click the button to create a DB4S certificate (that&apos;s your identity). That&apos;ll give you a certificate file (save it to your local disk).&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Go to the Remote tab in DB4S Preferences. Click the button to add a new certificate to DB4S and choose the just downloaded certificate file.&lt;/li&gt;&lt;/ol&gt;&lt;p&gt;Now the Remote panel shows your identity and you can add remote databases.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;БД с сайта dbhub.io могут быть добавлены в DB4S. Для начала вам нужен ID:&lt;/p&gt;&lt;ol style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Войдите на сайт dbhub.io (можно использовать аккаунт GitHub или что хотите)&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Нажмите кнопку создать DB4S сертификат (это и есть ваш ID). Будет создан файл сертификата (сохраните его на локальном диске).&lt;/li&gt;&lt;li style=&quot; margin-top:0px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;Перейдите во вкладку Remote в настройках DB4S. Нажмите кнопку, чтобы добавить новый сертификат в DB4S, и выберите только что загруженный файл сертификата.&lt;/li&gt;&lt;/ol&gt;&lt;p&gt;Теперь во вкладке Remote должна отображаться ваш ID, и вы можете добавлять удаленные базы данных.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>RemoteModel</name>
    <message>
        <location filename="../RemoteModel.cpp" line="100"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="obsolete">Версия</translation>
    </message>
    <message>
        <location filename="../RemoteModel.cpp" line="100"/>
        <source>Last modified</source>
        <translation>Изменен</translation>
    </message>
    <message>
        <location filename="../RemoteModel.cpp" line="100"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../RemoteModel.cpp" line="100"/>
        <source>Commit</source>
        <translation>Коммит</translation>
    </message>
    <message>
        <location filename="../RemoteModel.cpp" line="240"/>
        <source>bytes</source>
        <translation>байт</translation>
    </message>
</context>
<context>
    <name>RemotePushDialog</name>
    <message>
        <location filename="../RemotePushDialog.ui" line="14"/>
        <source>Push database</source>
        <translation>Отправить БД</translation>
    </message>
    <message>
        <location filename="../RemotePushDialog.ui" line="22"/>
        <source>Database na&amp;me to push to</source>
        <translation>&amp;Имя БД</translation>
    </message>
    <message>
        <location filename="../RemotePushDialog.ui" line="39"/>
        <source>Commit message</source>
        <translation>Сообщение</translation>
    </message>
    <message>
        <location filename="../RemotePushDialog.ui" line="49"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Oxygen-Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../RemotePushDialog.ui" line="63"/>
        <source>Database licence</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="../RemotePushDialog.ui" line="83"/>
        <source>Public</source>
        <translation>Публичный</translation>
    </message>
    <message>
        <location filename="../RemotePushDialog.ui" line="96"/>
        <source>Branch</source>
        <translation>Ветка</translation>
    </message>
    <message>
        <location filename="../RemotePushDialog.ui" line="116"/>
        <source>Force push</source>
        <translation>Принудительно</translation>
    </message>
    <message>
        <location filename="../RemotePushDialog.cpp" line="47"/>
        <source>Database will be public. Everyone has read access to it.</source>
        <translation>БД будет публичной. У каждого будет доступ на чтение к ней.</translation>
    </message>
    <message>
        <location filename="../RemotePushDialog.cpp" line="49"/>
        <source>Database will be private. Only you have access to it.</source>
        <translation>БД будет конфиденциальной. Только у вас будет доступ к ней.</translation>
    </message>
    <message>
        <location filename="../RemotePushDialog.cpp" line="53"/>
        <source>Use with care. This can cause remote commits to be deleted.</source>
        <translation>Используйте с осторожностью. Это может привести к удалению существующих коммитов.</translation>
    </message>
    <message>
        <location filename="../RemotePushDialog.cpp" line="111"/>
        <source>Unspecified</source>
        <translation>Неуказано</translation>
    </message>
</context>
<context>
    <name>SqlExecutionArea</name>
    <message>
        <location filename="../SqlExecutionArea.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="66"/>
        <source>Find previous match [Shift+F3]</source>
        <translation>Найти предыдущее совпадение [Shift+F3]</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="69"/>
        <source>Find previous match with mapping</source>
        <translation>Найти предыдущее совпадение, закольцевав поиск</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="76"/>
        <source>Shift+F3</source>
        <translation>Shift+F3</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="90"/>
        <source>The found pattern must be a whole word</source>
        <translation>Найденный шаблон должен быть целым словом</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="93"/>
        <source>Whole Words</source>
        <translation>Слова Полностью</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="103"/>
        <source>Text pattern to find considering the checks in this frame</source>
        <translation>Шаблон для поиска, учитывая все проверки</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="106"/>
        <source>Find in editor</source>
        <translation>Найти в редакторе</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="116"/>
        <source>The found pattern must match in letter case</source>
        <translation>У найденного шаблона должен совпадать регистр</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="119"/>
        <source>Case Sensitive</source>
        <translation>Учитывать Регистр</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="126"/>
        <source>Find next match [Enter, F3]</source>
        <translation>Найти следующее совпдение [Enter, F3]</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="129"/>
        <source>Find next match with wrapping</source>
        <translation>Найти следующее совпадение, закольцевав поиск</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="136"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="143"/>
        <source>Interpret search pattern as a regular expression</source>
        <translation>Интерпретировать шаблон поиска как регулярное выражение</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="146"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;When checked, the pattern to find is interpreted as a UNIX regular expression. See &lt;a href=&quot;https://en.wikibooks.org/wiki/Regular_Expressions&quot;&gt;Regular Expression in Wikibooks&lt;/a&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;При проверке шаблон для поиска интерпретируется как регулярное выражение UNIX. &lt;a href=&quot;https://en.wikibooks.org/wiki/Regular_Expressions&quot;&gt;Узнать больше о Регулярных выражениях на Wikibooks.org&lt;/a&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="149"/>
        <source>Regular Expression</source>
        <translation>Регулярное выражение</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="169"/>
        <location filename="../SqlExecutionArea.ui" line="172"/>
        <source>Close Find Bar</source>
        <translation>Закрыть Поисковую Панель</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="217"/>
        <location filename="../SqlExecutionArea.ui" line="238"/>
        <source>Results of the last executed statements</source>
        <translation>Результаты последних выполненных операторов</translation>
    </message>
    <message>
        <location filename="../SqlExecutionArea.ui" line="220"/>
        <source>This field shows the results and status codes of the last executed statements.</source>
        <translation>Это поле показывает результаты и коды статусов последних выполненных операторов.</translation>
    </message>
    <message>
        <source>Export to &amp;CSV</source>
        <translation type="vanished">Экспортировать в &amp;CSV</translation>
    </message>
    <message>
        <source>Save as &amp;view</source>
        <translation type="vanished">Сохранить как &amp;представление</translation>
    </message>
    <message>
        <source>Save as view</source>
        <translation type="vanished">Сохранить как представление</translation>
    </message>
    <message>
        <source>Please specify the view name</source>
        <translation type="vanished">Укажите имя представления</translation>
    </message>
    <message>
        <source>There is already an object with that name. Please choose a different name.</source>
        <translation type="vanished">Объект с указанным именем уже существует. Выберите другое имя. </translation>
    </message>
    <message>
        <source>View successfully created.</source>
        <translation type="vanished">Представление успешно создано.</translation>
    </message>
    <message>
        <source>Error creating view: %1</source>
        <translation type="vanished">Ошибка создания представления: %1</translation>
    </message>
</context>
<context>
    <name>SqlUiLexer</name>
    <message>
        <location filename="../SqlUiLexer.cpp" line="67"/>
        <source>(X) The abs(X) function returns the absolute value of the numeric argument X.</source>
        <translation>(X) Функция abs(X) возвращает модуль числа аргумента X.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="68"/>
        <source>() The changes() function returns the number of database rows that were changed or inserted or deleted by the most recently completed INSERT, DELETE, or UPDATE statement.</source>
        <translation>() Функция changes() возвращает количество строк в базе данных, которые были изменены, вставлены или удалены после удачного выполнения INSERT, DELETE или UPDATE.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="69"/>
        <source>(X1,X2,...) The char(X1,X2,...,XN) function returns a string composed of characters having the unicode code point values of integers X1 through XN, respectively. </source>
        <translation>(X1,X2,...) Функция char(X1,X2,...,XN) возвращает строку составленную из символов, переданных в качестве аргументов. </translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="70"/>
        <source>(X,Y,...) The coalesce() function returns a copy of its first non-NULL argument, or NULL if all arguments are NULL</source>
        <translation>(X,Y,...) Функция coalesce() возвращает копию первого аргумента не равного NULL иначе если такого нет то возвращается NULL</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="71"/>
        <source>(X,Y) The glob(X,Y) function is equivalent to the expression &quot;Y GLOB X&quot;.</source>
        <translation>(X,Y) Функция glob(X,Y) эквивалент выражению &quot;Y GLOB X&quot;.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="72"/>
        <source>(X,Y) The ifnull() function returns a copy of its first non-NULL argument, or NULL if both arguments are NULL.</source>
        <translation>(X,Y) Функция ifnull() возвращает копию первого аргумента не равного NULL иначе если оба аргумента равны NULL то возвращает NULL.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="73"/>
        <source>(X,Y) The instr(X,Y) function finds the first occurrence of string Y within string X and returns the number of prior characters plus 1, or 0 if Y is nowhere found within X.</source>
        <translation>(X,Y) Функция instr(X,Y) возвращает количество символов, начиная с которого в строке X найденна подстрока Y или 0 если таковая не обнаружена.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="74"/>
        <source>(X) The hex() function interprets its argument as a BLOB and returns a string which is the upper-case hexadecimal rendering of the content of that blob.</source>
        <translation>(X) Функция hex() интерпретирует аргумент как BLOB и возвращает строку в 16-ричной системе счисления с содержимым аргумента.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="75"/>
        <source>() The last_insert_rowid() function returns the ROWID of the last row insert from the database connection which invoked the function.</source>
        <translation>() Функция last_insert_rowid() возвращает ROWID последней вставленной строки.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="76"/>
        <source>(X) For a string value X, the length(X) function returns the number of characters (not bytes) in X prior to the first NUL character.</source>
        <translation>(X) Для строкового значения X, функция length(X) возвращает количество символов (не байт) от начала строки до первого символа &apos;\0&apos;.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="77"/>
        <source>(X,Y) The like() function is used to implement the &quot;Y LIKE X&quot; expression.</source>
        <translation>(X,Y) Фукнция like() эквивалент выражению &quot;Y LIKE X&quot;.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="78"/>
        <source>(X,Y,Z) The like() function is used to implement the &quot;Y LIKE X ESCAPE Z&quot; expression.</source>
        <translation>(X,Y,Z) Функция like() эквивалент выражения &quot;Y LIKE X ESCAPE Z&quot;.</translation>
    </message>
    <message>
        <source>(X) The load_extension(X) function loads SQLite extensions out of the shared library file named X.</source>
        <translation type="vanished">(X) Функция load_extension(X) загружает расширение SQLite из файла библиотеки динамической компоновки X.</translation>
    </message>
    <message>
        <source>(X,Y) The load_extension(X) function loads SQLite extensions out of the shared library file named X using the entry point Y.</source>
        <translation type="vanished">(X,Y) Функция load_extension(X,Y) загружает расширение SQLite из файла библиотеки динамической компоновки X, используя точку входа Y.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="79"/>
        <source>(X) The load_extension(X) function loads SQLite extensions out of the shared library file named X.
Use of this function must be authorized from Preferences.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="80"/>
        <source>(X,Y) The load_extension(X) function loads SQLite extensions out of the shared library file named X using the entry point Y.
Use of this function must be authorized from Preferences.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="81"/>
        <source>(X) The lower(X) function returns a copy of string X with all ASCII characters converted to lower case.</source>
        <translation>(X) Функция lower(X) возвращает копию строки X, в которой все ACSII символы переведены в нижний регистр.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="82"/>
        <source>(X) ltrim(X) removes spaces from the left side of X.</source>
        <translation>(X) ltrim(X) удаляет символы пробелов слева для строки X.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="83"/>
        <source>(X,Y) The ltrim(X,Y) function returns a string formed by removing any and all characters that appear in Y from the left side of X.</source>
        <translation>(X,Y) Функция ltrim(X,Y) возвращает новую строку путем удаления из строки X слева любого символа из Y.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="84"/>
        <source>(X,Y,...) The multi-argument max() function returns the argument with the maximum value, or return NULL if any argument is NULL.</source>
        <translation>(X,Y,...) Функция max() возвращает аргумент с максимальным значением, либо NULL если хотябы один аргумент равен NULL.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="85"/>
        <source>(X,Y,...) The multi-argument min() function returns the argument with the minimum value.</source>
        <translation>(X,Y,...) Функция min() возвращает аргумент с минимальным значением.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="86"/>
        <source>(X,Y) The nullif(X,Y) function returns its first argument if the arguments are different and NULL if the arguments are the same.</source>
        <translation>(X,Y) Функция nullif(X,Y) возвращает первый аргумент если аргументы различны либо NULL если они одинаковы.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="87"/>
        <source>(FORMAT,...) The printf(FORMAT,...) SQL function works like the sqlite3_mprintf() C-language function and the printf() function from the standard C library.</source>
        <translation>(FORMAT,...) Функция printf(FORMAT,...) работает так же как printf() из стандартной библиотеки языка программирования Си.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="88"/>
        <source>(X) The quote(X) function returns the text of an SQL literal which is the value of its argument suitable for inclusion into an SQL statement.</source>
        <translation>(X) Функция quote(X) возвращает измененную строку X, которую можно использовать в SQL выражениях.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="89"/>
        <source>() The random() function returns a pseudo-random integer between -9223372036854775808 and +9223372036854775807.</source>
        <translation>() Функция random() возвращает псевдо случайное целочисленное значение из диапозона от-9223372036854775808 до +9223372036854775807.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="90"/>
        <source>(N) The randomblob(N) function return an N-byte blob containing pseudo-random bytes.</source>
        <translation>(N) Функция randomblob(N) возвращает N-байтный BLOB, содержащий псевдо случайные байты.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="91"/>
        <source>(X,Y,Z) The replace(X,Y,Z) function returns a string formed by substituting string Z for every occurrence of string Y in string X.</source>
        <translation>(X,Y,Z) Функция replace(X,Y,Z) возвращает новую строку на основе строки X, заменой всех подстрок Y на Z.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="92"/>
        <source>(X) The round(X) function returns a floating-point value X rounded to zero digits to the right of the decimal point.</source>
        <translation>(X) Функция round(X) округляет X до целого значения.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="93"/>
        <source>(X,Y) The round(X,Y) function returns a floating-point value X rounded to Y digits to the right of the decimal point.</source>
        <translation>(X,Y) Функция round(X,Y) округляет X до Y чисел после запятой справа.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="94"/>
        <source>(X) rtrim(X) removes spaces from the right side of X.</source>
        <translation>(X) rtrim(X) удаляет символы пробела справа строки X.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="95"/>
        <source>(X,Y) The rtrim(X,Y) function returns a string formed by removing any and all characters that appear in Y from the right side of X.</source>
        <translation>(X,Y) Функция rtrim(X,Y) возвращает новую строку путем удаления из строки X справа любого символа из строки Y.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="96"/>
        <source>(X) The soundex(X) function returns a string that is the soundex encoding of the string X.</source>
        <translation>(X) Функция soundex(X) возвращает копию строки X, кодированную в формате soundex.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="97"/>
        <source>(X,Y) substr(X,Y) returns all characters through the end of the string X beginning with the Y-th.</source>
        <translation>(X,Y) substr(X,Y) возвращает подстроку из строки X, начиная с Y-го символа.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="98"/>
        <source>(X,Y,Z) The substr(X,Y,Z) function returns a substring of input string X that begins with the Y-th character and which is Z characters long.</source>
        <translation>(X,Y,Z) Функция substr(X,Y,Z) возвращает подстроку из строки X, начиная с Y-го символа, длинной Z-символов.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="99"/>
        <source>() The total_changes() function returns the number of row changes caused by INSERT, UPDATE or DELETE statements since the current database connection was opened.</source>
        <translation>() Функция total_changes() возвращает количество строк измененных с помощью INSERT, UPDATE или DELETE, начиная с того момента как текущее подключение к базе данных было открыто.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="100"/>
        <source>(X) trim(X) removes spaces from both ends of X.</source>
        <translation>(X) trim(X) удаляет пробелы с обоих сторон строки X.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="101"/>
        <source>(X,Y) The trim(X,Y) function returns a string formed by removing any and all characters that appear in Y from both ends of X.</source>
        <translation>(X,Y) Функция trim(X,Y) создает новую строку из X, путем удаления с обоих концов символов, которые присутсвуют в строке Y.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="102"/>
        <source>(X) The typeof(X) function returns a string that indicates the datatype of the expression X.</source>
        <translation>(X) Функция typeof(X) возвращает строку с типом данных выражения X.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="103"/>
        <source>(X) The unicode(X) function returns the numeric unicode code point corresponding to the first character of the string X.</source>
        <translation>(X) Функция unicode(X) возвращает числовое значение UNICODE кода символа.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="104"/>
        <source>(X) The upper(X) function returns a copy of input string X in which all lower-case ASCII characters are converted to their upper-case equivalent.</source>
        <translation>(X) Функция upper(X) возвращает копию строки X, в которой для каждого ASCII символа регистр будет перобразован из нижнего в верхний.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="105"/>
        <source>(N) The zeroblob(N) function returns a BLOB consisting of N bytes of 0x00.</source>
        <translation>(N) Функция zeroblob(N) возвращает BLOB размером N байт со значениями 0x00.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="107"/>
        <location filename="../SqlUiLexer.cpp" line="108"/>
        <location filename="../SqlUiLexer.cpp" line="109"/>
        <location filename="../SqlUiLexer.cpp" line="110"/>
        <source>(timestring,modifier,modifier,...)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="111"/>
        <source>(format,timestring,modifier,modifier,...)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="113"/>
        <source>(X) The avg() function returns the average value of all non-NULL X within a group.</source>
        <translation>(X) Функция avg() возвращает среднее значение для всех не равных NULL значений группы.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="114"/>
        <source>(X) The count(X) function returns a count of the number of times that X is not NULL in a group.</source>
        <translation>(X) Функция count(X) возвращает количество строк, в которых X не равно NULL в группе.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="115"/>
        <source>(X) The group_concat() function returns a string which is the concatenation of all non-NULL values of X.</source>
        <translation>(X) Функция group_concat() возвращает строку из всех значений X не равных NULL.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="116"/>
        <source>(X,Y) The group_concat() function returns a string which is the concatenation of all non-NULL values of X. If parameter Y is present then it is used as the separator between instances of X.</source>
        <translation>(X,Y) Функция group_concat() возвращает строку из всех значений X не равных NULL. Y - разделитель между значениями X.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="117"/>
        <source>(X) The max() aggregate function returns the maximum value of all values in the group.</source>
        <translation>(X) Аггрегатная функция max() возвращает максимальное значение для X.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="118"/>
        <source>(X) The min() aggregate function returns the minimum non-NULL value of all values in the group.</source>
        <translation>(X) Аггрегатная функция min() возвращает минимальное значение для X.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="119"/>
        <location filename="../SqlUiLexer.cpp" line="120"/>
        <source>(X) The sum() and total() aggregate functions return sum of all non-NULL values in the group.</source>
        <translation>(X) Аггрегатные функции sum() и total() возвращают сумму всех не NULL значений для X.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="122"/>
        <source>() The number of the row within the current partition. Rows are numbered starting from 1 in the order defined by the ORDER BY clause in the window definition, or in arbitrary order otherwise.</source>
        <translation>() Число строк в текущем разделе. Строки нумеруются начиная с 1 в порядке, определенном выражением ORDER BY, или иначе в произвольном порядке.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="123"/>
        <source>() The row_number() of the first peer in each group - the rank of the current row with gaps. If there is no ORDER BY clause, then all rows are considered peers and this function always returns 1.</source>
        <translation>() Функция row_number() возвращает номер первой строки в каждой группе - ранг текущей строки с разрывами. Если не существует выражения ORDER BY, все строки считаются одноранговыми, и эта функция всегда возвращает 1.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="124"/>
        <source>() The number of the current row&apos;s peer group within its partition - the rank of the current row without gaps. Partitions are numbered starting from 1 in the order defined by the ORDER BY clause in the window definition. If there is no ORDER BY clause, then all rows are considered peers and this function always returns 1. </source>
        <translation>() Число одноранговой группы текущей строки в своем разделе - ранг текущей строки без пробелов. Разделы нумеруются, начиная с 1 в порядке, определенном выражением ORDER BY в определении окна. Если не существует предложения ORDER BY, все строки считаются одноранговыми, и эта функция всегда возвращает 1. </translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="125"/>
        <source>() Despite the name, this function always returns a value between 0.0 and 1.0 equal to (rank - 1)/(partition-rows - 1), where rank is the value returned by built-in window function rank() and partition-rows is the total number of rows in the partition. If the partition contains only one row, this function returns 0.0. </source>
        <translation>() Несмотря на имя, эта функция всегда возвращает значение между 0.0 и 1.0, равное (rank-1) / (partition-rows-1), где rank - это значение, возвращаемое встроенной функцией window rank () rows - это общее количество строк в разделе. Если раздел содержит только одну строку, эта функция возвращает 0.0. </translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="126"/>
        <source>() The cumulative distribution. Calculated as row-number/partition-rows, where row-number is the value returned by row_number() for the last peer in the group and partition-rows the number of rows in the partition.</source>
        <translation>() Кумулятивное распределение. Рассчитывается как номер-строки / строки-раздела, где номер-строки - это значение, возвращаемое row_number() для последнего однорангового узла в группе, а строки-раздела- количество строк в разделе.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="127"/>
        <source>(N) Argument N is handled as an integer. This function divides the partition into N groups as evenly as possible and assigns an integer between 1 and N to each group, in the order defined by the ORDER BY clause, or in arbitrary order otherwise. If necessary, larger groups occur first. This function returns the integer value assigned to the group that the current row is a part of.</source>
        <translation>(N) Аргумент N обрабатывается как целое число. Эта функция делит раздел на N групп как можно более равномерно и назначает целое число от 1 до N каждой группе в порядке, определенном выражением ORDER BY, или в произвольном порядке, при его отсутствии. При необходимости сначала появляются большие группы. Эта функция возвращает целочисленное значение, присвоенное группе, в которой находится текущая строка.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="128"/>
        <source>(expr) Returns the result of evaluating expression expr against the previous row in the partition. Or, if there is no previous row (because the current row is the first), NULL.</source>
        <translation>(expr) Возвращает результат вычисления выражения expr в предыдущей строке раздела. Или, если нет предыдущей строки (поскольку текущая строка является первой), NULL.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="129"/>
        <source>(expr,offset) If the offset argument is provided, then it must be a non-negative integer. In this case the value returned is the result of evaluating expr against the row offset rows before the current row within the partition. If offset is 0, then expr is evaluated against the current row. If there is no row offset rows before the current row, NULL is returned.</source>
        <translation>(expr, offset) Если аргумент offset укзан, то он должен быть неотрицательным целым числом. В этом случае возвращаемое значение является результатом вычисления expr в строках смещения строк до текущей строки в разделе. Если смещение равно 0, то expr вычисляется относительно текущей строки. Если перед текущей строкой нет строк смещения строк, возвращается NULL.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="130"/>
        <location filename="../SqlUiLexer.cpp" line="133"/>
        <source>(expr,offset,default) If default is also provided, then it is returned instead of NULL if the row identified by offset does not exist.</source>
        <translation>(expr, offset, default) Если задано значение по умолчанию, оно возвращается вместо NULL, если строка, идентифицированная с помощью смещения, не существует.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="131"/>
        <source>(expr) Returns the result of evaluating expression expr against the next row in the partition. Or, if there is no next row (because the current row is the last), NULL.</source>
        <translation>(expr) Возвращает результат вычисления выражения expr в следующей строке раздела. Или, если нет следующей строки (поскольку последняя строка является последней), NULL.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="132"/>
        <source>(expr,offset) If the offset argument is provided, then it must be a non-negative integer. In this case the value returned is the result of evaluating expr against the row offset rows after the current row within the partition. If offset is 0, then expr is evaluated against the current row. If there is no row offset rows after the current row, NULL is returned.</source>
        <translation>(expr, offset) Если аргумент offset указан, то он должен быть неотрицательным целым числом. В этом случае возвращаемое значение является результатом вычисления expr в строках смещения строк после текущей строки в разделе. Если смещение равно 0, то expr вычисляется относительно текущей строки. Если после текущей строки нет строк смещения строки, возвращается NULL.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="134"/>
        <source>(expr) This built-in window function calculates the window frame for each row in the same way as an aggregate window function. It returns the value of expr evaluated against the first row in the window frame for each row.</source>
        <translation>(expr) Эта встроенная Оконная Функция вычисляет Оконный Кадр для каждой строки так же, как Функция Окна агрегата. Она возвращает значение выполнения выражения expr, оцениваемое по отношению к первой строке в оконном фрейме для каждой строки.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="135"/>
        <source>(expr) This built-in window function calculates the window frame for each row in the same way as an aggregate window function. It returns the value of expr evaluated against the last row in the window frame for each row.</source>
        <translatorcomment>(expr) Эта встроенная Оконная Функция вычисляет Оконный Кадр для каждой строки так же, как Функция Окна агрегата. Она возвращает значение выполнения выражения expr, оцениваемое по отношению к последней строке в оконном фрейме для каждой строки.</translatorcomment>
        <translation>(expr) Эта встроенная функция окна вычисляет оконный кадр для каждой строки так же, как функция окна агрегата. Он возвращает значение expr, оцениваемое по последней строке в оконном фрейме для каждой строки.</translation>
    </message>
    <message>
        <location filename="../SqlUiLexer.cpp" line="136"/>
        <source>(expr,N) This built-in window function calculates the window frame for each row in the same way as an aggregate window function. It returns the value of expr evaluated against the row N of the window frame. Rows are numbered within the window frame starting from 1 in the order defined by the ORDER BY clause if one is present, or in arbitrary order otherwise. If there is no Nth row in the partition, then NULL is returned.</source>
        <translation>(expr, N) Эта встроенная функция окна вычисляет оконный фрейм для каждой строки так же, как функция окна агрегата. Она возвращает значение выполнения выражения expr, оцениваемое по строке N оконного фрейма. Строки нумеруются в рамке окна, начиная с 1 в порядке, определенном выражением ORDER BY, если оно присутствует, или в произвольном порядке в противном случае. Если в разделе нет N-й строки, возвращается NULL.</translation>
    </message>
</context>
<context>
    <name>SqliteTableModel</name>
    <message>
        <source>References %1(%2)
Hold Ctrl+Shift and click to jump there</source>
        <translation type="vanished">Ссылается на %1(%2)
Нажмите Ctrl+Shift и клик чтобы переместиться туда</translation>
    </message>
    <message>
        <location filename="../sqlitetablemodel.cpp" line="27"/>
        <source>reading rows</source>
        <translation>читаем строки</translation>
    </message>
    <message>
        <location filename="../sqlitetablemodel.cpp" line="265"/>
        <source>loading...</source>
        <translation>загрузка...</translation>
    </message>
    <message>
        <location filename="../sqlitetablemodel.cpp" line="307"/>
        <source>References %1(%2)
Hold %3Shift and click to jump there</source>
        <translation>Ссылается на %1(%2)
Нажмите %3Shift и клик чтобы переместиться туда</translation>
    </message>
    <message>
        <location filename="../sqlitetablemodel.cpp" line="407"/>
        <source>Error changing data:
%1</source>
        <translation>Ошибка изменения данных:
%1</translation>
    </message>
    <message>
        <location filename="../sqlitetablemodel.cpp" line="696"/>
        <source>retrieving list of columns</source>
        <translation>получаем список колонок</translation>
    </message>
    <message>
        <location filename="../sqlitetablemodel.cpp" line="959"/>
        <source>Fetching data...</source>
        <translation>Подгружаем данные...</translation>
    </message>
    <message>
        <location filename="../sqlitetablemodel.cpp" line="960"/>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
</context>
<context>
    <name>VacuumDialog</name>
    <message>
        <location filename="../VacuumDialog.ui" line="14"/>
        <source>Compact Database</source>
        <translatorcomment>Не понятно, что лучше &quot;уплотнение&quot; или &quot;сжатие&quot;?</translatorcomment>
        <translation>Уплотнение базы данных</translation>
    </message>
    <message>
        <location filename="../VacuumDialog.ui" line="26"/>
        <source>Warning: Compacting the database will commit all of your changes.</source>
        <translation>Предупреждение: Уплотнение базы данных зафиксирует все изменения, которые были сделаны.</translation>
    </message>
    <message>
        <location filename="../VacuumDialog.ui" line="39"/>
        <source>Please select the databases to co&amp;mpact:</source>
        <translation>Выберите объекты для &amp;уплотнения:</translation>
    </message>
    <message>
        <source>Warning: Compacting the database will commit all changes you made.</source>
        <translation type="vanished">Предупреждение: Уплотнение базы данных зафиксирует все изменения, которые были сделаны.</translation>
    </message>
    <message>
        <source>Please select the objects to compact:</source>
        <translation type="vanished">Выберите объекты для уплотнения:</translation>
    </message>
</context>
</TS>

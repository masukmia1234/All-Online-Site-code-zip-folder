# UVa Solutions

See my progress: http://uhunt.onlinejudge.org/id/706597

Used language: C/C++

Important notice:

Some of the solutions may seem a bit ugly :D.
Some of them are too old, as they were solved when I had a very little knowledge
about programming.


## Line Sweeps and Other Miscellaneous Computational Geometry 
:heavy_check_mark: corral (Line Sweep) <br>
:heavy_check_mark: crazy (Checking if Point is Inside Polygon) <br>
:heavy_check_mark: expand (Ad Hoc Geometry) <br>
:heavy_check_mark: fence4 (Ad Hoc Vector Geometry) <br>
:heavy_check_mark: fpot (Line Sweep) <br>
:heavy_check_mark: island (Hard Floodfill) <br>
:heavy_check_mark: newbarn (Ad Hoc Geometry) <br>
:heavy_check_mark: rescue (Ad Hoc Geometry) <br>
:white_circle: roping

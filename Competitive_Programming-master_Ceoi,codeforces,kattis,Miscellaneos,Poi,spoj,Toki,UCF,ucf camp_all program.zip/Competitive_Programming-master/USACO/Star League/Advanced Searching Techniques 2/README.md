## Segment Trees
:heavy_check_mark: hotel (Unusual Lazy Propagation Segment Tree) <br>
:heavy_check_mark: lineupg (Classic RMQ Segment Tree) <br>
:heavy_check_mark: lites (Lazy Propagation Segment Tree)

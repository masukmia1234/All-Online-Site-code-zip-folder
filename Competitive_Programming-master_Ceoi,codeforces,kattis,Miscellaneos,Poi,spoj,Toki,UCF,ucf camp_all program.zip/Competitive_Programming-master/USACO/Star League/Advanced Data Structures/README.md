## Hashing and STL
:heavy_check_mark: bclgold (Greedy Ad Hoc and Binary Search with Hashing) <br>
:heavy_check_mark: gourmet (Greedy Ad Hoc with STL Set) <br>
:heavy_check_mark: horizon (Ad Hoc with STL Multiset and Map) <br>
:heavy_check_mark: letter (Suffix Automaton) <br>
:heavy_check_mark: lines (Ad Hoc Geometry with STL Set) <br>
:heavy_check_mark: lineup2 (Hashing Sweep)  <br>
:heavy_check_mark: patterns (Hashing with Binary Search)

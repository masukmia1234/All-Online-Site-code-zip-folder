## Fenwick Trees (BITs) and Lowest Common Ancestor (LCA)
:heavy_check_mark: cowemb (Computational Geometry With BIT) <br>
:heavy_check_mark: cowpol (Fast LCA) <br>
:heavy_check_mark: distance (Fast LCA) <br>
:heavy_check_mark: protest (Dynamic Programming With BIT) <br>
:heavy_check_mark: running (Ad Hoc With BIT) <br>
:heavy_check_mark: slowdown (DFS and BIT on a Tree)

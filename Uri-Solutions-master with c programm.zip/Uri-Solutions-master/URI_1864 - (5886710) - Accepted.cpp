#include <iostream>

using namespace std;

int main() {

    char s[35] = "LIFE IS NOT A PROBLEM TO BE SOLVED";

    int n;

    cin >> n;

    for(int i = 0; i < n; i++)
        cout << s[i];

    cout << endl;

    return 0;
}

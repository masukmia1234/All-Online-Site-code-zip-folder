#include <iostream>
#include <stdio.h>

using namespace std;

int main() {

    unsigned long long int n, b;

    cin >> n;

     b = (n*(n-3))/2;

    cout << b << endl;

    return 0;
}

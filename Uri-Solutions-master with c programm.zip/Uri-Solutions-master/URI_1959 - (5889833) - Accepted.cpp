#include <iostream>

using namespace std;

int main(){

    unsigned long int n, l;

    cin >> n >> l;

    cout << n*l << endl;

    return 0;
}

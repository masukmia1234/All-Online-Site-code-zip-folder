#include <stdio.h>

int main(){

    double pi = 3.14159, r;

    scanf("%lf", &r);

    printf("A=%.4f\n", r*r*pi);

    return 0;
}

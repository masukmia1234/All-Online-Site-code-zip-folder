#include <iostream>

using namespace std;

int main(){

    int i;

    cin >> i;

    cout << "Feliz nat";

    while(i--)
        cout << 'a';

    cout << "l!" << endl;

    return 0;
}

#include <iostream>

using namespace std;

int main() {

    unsigned long long int n;

    cin >> n;

    cout << n - 2 << endl;

    return 0;
}

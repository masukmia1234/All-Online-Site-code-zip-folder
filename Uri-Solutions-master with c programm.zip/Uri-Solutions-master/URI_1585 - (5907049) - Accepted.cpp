#include <iostream>

using namespace std;

int main() {

    int n, x, y;

    cin >> n;

    while(n--){

        cin >> x >> y;

        cout << (x*y)/2 << " cm2" << endl;

    }

    return 0;
}

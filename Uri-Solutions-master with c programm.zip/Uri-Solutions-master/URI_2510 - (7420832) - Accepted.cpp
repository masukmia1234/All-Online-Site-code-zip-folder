#include <iostream>

using namespace std;

int main() {

    int t;

    cin >> t;

    while(t--)
        cout << "Y" << endl;

    return 0;
}

#include <iostream>

using namespace std;

int main(){

    unsigned long int t, n;

    cin >> t;

    while(t--){

        cin >> n;

        cout << (n+1)/2 << endl;

    }

    return 0;
}

#include <iostream>
#include <iomanip>

using namespace std;

int main() {

    int n, r1, r2;

    cin >> n;

    while(n--){

        cin >> r1 >> r2;

        cout << r1 + r2 << endl;

    }

    return 0;
}

#include <iostream>

using namespace std;

int main() {

    int t1, t2, t3, t4;

    cin >> t1 >> t2 >> t3 >> t4;

    cout << t1 + t2 + t3 + t4 - 3 << endl;

    return 0;
}

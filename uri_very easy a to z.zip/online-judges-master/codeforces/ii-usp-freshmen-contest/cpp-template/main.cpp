/*
II USP Freshmen Contest (http://codeforces.com/gym/100985)
{{name}} ({{url}})
*/

#include <bits/stdc++.h>

using namespace std;

int main(void) {
    ios::sync_with_stdio(false);

    return EXIT_SUCCESS;
}

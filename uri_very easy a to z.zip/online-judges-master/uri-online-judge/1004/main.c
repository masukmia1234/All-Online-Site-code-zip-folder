/*
Produto Simples
https://www.urionlinejudge.com.br/judge/pt/problems/view/1004
*/

#include <stdio.h>

int main (void) {
    int a, b;

    scanf("%d %d", &a, &b);
    printf("SOMA = %d\n", a + b);

    return 0;
}

/*
Extremamente Básico
https://www.urionlinejudge.com.br/judge/pt/problems/view/1001
*/

#include <stdio.h>

int main (void) {
    int a, b;

    scanf("%d %d", &a, &b);

    printf("X = %d\n", a + b);

    return 0;
}

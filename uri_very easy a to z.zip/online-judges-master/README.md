# Online Judges - Soluções

Minhas soluções para problemas de _onlines judges_ :blush:


## [URI Online Judge](https://www.urionlinejudge.com.br/)

Meu perfil pode ser acessado [aqui](https://www.urionlinejudge.com.br/judge/pt/profile/74386) :point_left:

## [TopCoder](https://www.topcoder.com/)

Meu perfil pode ser acessado [aqui](https://www.topcoder.com/members/olegon.main) :point_left:

## [CodeForces](https://www.topcoder.com/)

Meu perfil pode ser acessado [aqui](http://codeforces.com/profile/_olegon) :point_left:

## [Hacker Rank](https://www.hackerrank.com/)

Meu perfil pode ser acessado [aqui](https://www.hackerrank.com/olegon) :point_left:

## [CodeChef](https://www.codechef.com/)

Meu perfil pode ser acessado [aqui](https://www.codechef.com/users/olegon) :point_left:

package URI_Problems_solution;

import java.util.Scanner;

public class URI_1172 {

	public static void main(String[] args) {
		int[] x = null;
		Scanner input=new Scanner(System.in);
		while (x.length <= 10) {
	///		x []= input.nextInt();
		}
		System.out.println(x);

	}

}

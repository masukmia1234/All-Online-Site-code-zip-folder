#include <cstdio>

int main()
{
	int x;
	int y;
	scanf("%d", &x);
	scanf("%d", &y);
	printf("X = %d\n", x + y);

    return 0;
}

# URI-Online-Judge-All-Problems-Solution List
This is an open source codes for you of URI online Judge.<br />
Here, I've added some URI problems solution in C, C++ and in Java languages.You can use these URI Online judge solutions in your coding time on URI..<br />
As a programmer, I first suggest you to try these code first. It will be the best if you do your own code. And obviously solving one problem more than 2-3 days of URI online judge not a good idea at all.
<br />
So here, You can get all the URI Online Judge Problems Solution and solve URI Problems easily all of the URI Problems. <br />
I may be add one problems solution in different languages(C, C++, Java). From them, C++/cpp is the best solution, Promise.<br />

You can get any individual URI online Judge Problem's Solution at https://urisolve.blogspot.com<br />

Contact with me at my mail for any problem : manirujjamanakash@gmail.com <br />
-----------------------------------------------<br />
Get all the URI problems solution and be a master on URI Online Judge.<br /><br />
Below solutions are available in this repository:<br />

<table class="table table-responsive">

<tr>
<th>URI Problem Number</th>
<th>URI Problem Name </th>
<th>URI Problem Solution Language</th>
</tr>


<tr>
<td><a href="https://github.com/ManiruzzamanAkash/URI-Online-Judge-All-Problems-Solution/blob/master/URI_1001.cpp">1001</a></td>
<td><a href="https://github.com/ManiruzzamanAkash/URI-Online-Judge-All-Problems-Solution/blob/master/URI_1001.cpp">Extremely Basic</a></td>
<td>C, <a href="https://github.com/ManiruzzamanAkash/URI-Online-Judge-All-Problems-Solution/blob/master/URI_1001.cpp">CPP</a>, <a href="https://github.com/ManiruzzamanAkash/URI-Online-Judge-All-Problems-Solution/blob/master/URI_1001.java">Java</a></td>
</tr>

<tr>
<td>1002</td>
<td>Area of a Circle</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1003</td>
<td>Simple Sum</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1004</td>
<td>Simple Product</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1005</td>
<td>Average 1</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1006</td>
<td>Average 2</td>
<td>C, CPP, Java</td>
</tr>


<tr>
<td>1007</td>
<td>Difference</td>
<td>C, CPP, Java</td>
</tr>


<tr>
<td>1008</td>
<td>Salary</td>
<td>C, CPP, Java</td>
</tr>


<tr>
<td>1009</td>
<td>Salary with Bonus</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1010</td>
<td>Simple Calculate</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1011</td>
<td>Sphere	Sequential</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1012</td>
<td>Area	Sequential</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1013</td>
<td>The Greatest</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1014</td>
<td>Consumption</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1015</td>
<td>Distance Between Two Points</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1016</td>
<td>Distance</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1017</td>
<td>Fuel Spent</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1018</td>
<td>Banknotes</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1019</td>
<td>Time Conversion</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1020</td>
<td>Age in Days</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1021</td>
<td>Banknotes and Coins</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1035</td>
<td>Selection Test 1</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1036</td>
<td>Bhaskara's Formula</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1037</td>
<td>Interval</td>
<td>C, CPP, Java</td>
</tr>

<tr>
<td>1038</td>
<td>Snack</td>
<td>C, CPP, Java</td>
</tr>
</table>
<br />..Adding Here more URI online Judge Solution..Just wait and star the repository..


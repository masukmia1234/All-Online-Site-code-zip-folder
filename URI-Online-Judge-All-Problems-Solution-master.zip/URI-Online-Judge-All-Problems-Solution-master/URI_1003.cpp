#include <cstdio>

int main()
{
	int x;
	int y;

	scanf("%d", &x);
	scanf("%d", &y);
	printf("SOMA = %d\n", x + y);

	return 0;
}
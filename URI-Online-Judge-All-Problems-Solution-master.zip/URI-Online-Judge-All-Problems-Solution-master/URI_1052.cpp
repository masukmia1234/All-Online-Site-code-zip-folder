#include <iostream>

using namespace std;

int main()
{
	int d;

	cin >> d;

	if(d == 1){
		cout << "January" << endl;
	}else if(d == 2){
		cout << "February" << endl;
	}else if(d == 3){
		cout << "March" << endl;
	}else if(d == 4){
		cout << "April" << endl;
	}else if(d == 5){
		cout << "May" << endl;
	}else if(d == 6){
		cout << "June" << endl;
	}else if(d == 7){
		cout << "July" << endl;
	}else if(d == 8){
		cout << "August" << endl;
	}else if(d == 9){
		cout << "September" << endl;
	}else if(d == 10){
		cout << "October" << endl;
	}else if(d == 11){
		cout << "November" << endl;
	}else if(d == 12){
		cout << "December" << endl;
	}

	return 0;
}
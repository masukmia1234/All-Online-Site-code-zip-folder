#include <cstdio>

int main()
{
	for (int i = 1; i <= 100; ++i)
	{
		/* code */
		if(i % 2 == 0)
			printf("%i\n", i);
	}

	return 0;
}
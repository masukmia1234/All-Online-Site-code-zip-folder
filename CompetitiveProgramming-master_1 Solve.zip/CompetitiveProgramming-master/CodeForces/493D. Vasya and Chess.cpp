#include <bits/stdc++.h>

using namespace std;

int n;

int main() {
    scanf("%d\n", &n);
    
    if(n % 2 == 0)
        puts("white\n1 2");
    else
        puts("black");
    
    return 0;
}


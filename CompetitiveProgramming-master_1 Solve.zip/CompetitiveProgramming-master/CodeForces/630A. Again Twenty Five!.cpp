#include <iostream>
#include <cstdlib>

using namespace std;

void main() {
	cout << 25 << endl;
}
